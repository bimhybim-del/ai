<?php /* Template Name: Referal Template */ ?>

<?php get_header() ?>
    <article id="header" class="pb-md-4">
        <script>
            document.querySelectorAll('.navbar-dark').forEach(nav => {
                nav.classList.add('navbar-light')
                nav.classList.remove('navbar-dark')
            })
        </script>
        <section class="parallax text-white " data-parallax="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/safe.webp">
            <div class="container py-5 d-flex align-items-center justify-content-center flex-column">
                <div class="row w-100">
                    <div class="col-12 col-md-11 col-lg-10 col-xl-9 mx-auto">
                        <h1 class="h1 fs-1 text-break text-center">
                            Dapatkan Penghasilan Tambahan dengan Program
                            Referral GajiHub
                        </h1>
                        <h2 class="fs-6 opacity-5 text-break text-center mt-2 mb-0 mx-md-5">
                            Mari jalin kerjasama dengan bergabung program referral GajiHub untuk membangun hubungan yang saling menguntungkan dan tumbuh bersama jutaan usaha di Indonesia.
                        </h2>
                    </div>
                </div>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-bottom">
                <polygon points="100,30 0,30 0,0 50,25 100,0"/>
            </svg>
        </section>
        <style>
            #header .container {
                min-height: 70vh;
            }
            #header .parallax:after {
                background-color:rgba(0,0,0,.75)
            }
            @media (min-width: 992px) {
                #header h1 {
                    font-size: calc(2rem + 1.75vw) !important;
                }
                #header .parallax:after {
                    background-color: transparent;
                    background-image: linear-gradient(90deg,rgba(0,0,0,.8) 0,rgba(0,0,0,.6) 45%,transparent 100%)
                }
            }
        </style>
        <section class="slice slice-lg delimiter-bottom" data-aos="fade-up" data-aos-delay="200">
            <div class="container py-5">
                <div class="row mb-5 justify-content-center text-center">
                    <div class="col-lg-7">
                        <h2 class="fs-1 text-break mb-3">Keuntungan yang akan Anda dapatkan</h2>
                    </div>
                </div>
                <!-- Card -->
                <div class="row justify-content-center text-center">
                    <div class="col-md-4 mb-5 mb-lg-0 ">
                        <div class="px-3 card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
                            <h3 class="fs-4 text-break mb-3">Komisi besar</h3>
                            <p class="opacity-5 text-break">Anda akan mendapatkan Rp 150.000 dari setiap nilai penjualan yang Anda lakukan.</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5 mb-lg-0">
                        <div class="px-3 card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
                            <h3 class="fs-4 text-break mb-3">Prospek Anda juga mendapatkan diskon</h3>
                            <p class="opacity-5 text-break">Untuk meningkatkan kemudahan dalam melakukan penjualan, prospek Anda juga akan mendapatkan diskon sebanyak 15% jika berlangganan selama setahun.</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5 mb-lg-0">
                        <div class="px-3 card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
                            <h3 class="fs-4 text-break mb-3">Mudah dan tanpa biaya</h3>
                            <p class="opacity-5 text-break">Tidak ada biaya yang perlu Anda keluarkan untuk bergabung program ini. Anda juga bisa mempromosikan software payroll dan HR GajiHub dimana saja.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="text-center py-5">
                    <a class="btn btn-warning rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="/daftar/"><div class="d-flex align-items-center"> <span class="ml-1 mr-2"> GABUNG SEKARANG </span> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40"> <path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path> <path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"></path> </svg></div> </a>                        </div>
                </div>
            <hr>
            </div>
        </section>

        <section class="slice slice-lg delimiter-bottom" data-aos="fade-up" data-aos-delay="500">
            <div class="container">
                <div class="row mb-5 pb-0 pb-lg-5 justify-content-center text-center">
                    <div class="col-lg-8">
                        <h2 class="fs-1 text-break mb-3"> Bagaimana cara kerja program referral GajiHub?
                        </h2>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-md-4 mb-4">
                        <div class="card bg-section-secondary border-0 shadow-none p-5 h-100">
                            <img class="mb-4" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/png/ref-join-color.png" width="60" height="60">
                            <h3 class="h4 font-weight-bolder lh-130 mb-4">Join program referral</h3>
                            <p class="opacity-5 text-break">Buat akun di GajiHub.com, lalu pilih opsi referral pada menu profil di pojok atas sebelah kanan. Buat kode referral mu dan salin kodenya.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card bg-section-secondary border-0 shadow-none p-5 h-100">
                            <img class="mb-4" src="https://kledo.com//wp-content/themes/new-theme/assets2/img/png/ref-global-color.png" width="60" height="60">
                            <h3 class="h4 font-weight-bolder lh-130 mb-4">Promosikan GajiHub</h3>
                            <p class="opacity-5 text-break">Gunakan kode yang Anda buat untuk mempromosikan software payroll dan HR GajiHub melalui artikel blog, email newsletter, media sosial, whatsapp, dan konten digital lainnya.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card bg-section-secondary border-0 shadow-none p-5 h-100">
                            <img class="mb-4" src="https://kledo.com//wp-content/themes/new-theme/assets2/img/png/ref-earning-color.png" width="60" height="60">
                            <h3 class="h4 font-weight-bolder lh-130">Dapatkan komisi</h3>
                            <p class="opacity-5 text-break">Anda akan mendapatkan komisi dari setiap prospek yang berlangganan minimal tiga bulan dengan kode referral milik Anda. Prospek Anda juga akan mendapatkan diskon 15% untuk minimal berlangganan selama setahun.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="slice slice-lg bg-section-secondary delimiter-bottom bg-theme-1 py-5" data-aos="fade-up" data-aos-delay="500">
            <div class="container py-2">
                <div class="row pb-5 justify-content-center text-center ">
                    <div class="col-lg-10">
                        <h2 class="fs-1 text-break text-white mb-3">Alasan mengapa Anda harus bergabung dengan program referral GajiHub
                        </h2>
                        <p class="opacity-9 text-break text-white">Kualitas dan target pasar adalah hal penting jika Anda ingin mempromosikan suatu produk, dan kami mengerti hal itu.
                            Berikut adalah unique selling point (USP) yang bisa Anda gunakan dalam mempromosikan GajiHub kepada prospek dan audiens Anda:
                        </p>

                    </div>
                    <div class="col-lg-8 mt-3 mt-lg-5"><img class="img-fluid" src="https://gajihub.com/wp-content/uploads/2022/05/gajihub-screenshot-payroll.jpg"></div>
                </div>
                <div class="row justify-content-center pt-0 pt-lg-5">
                    <div class="col-lg-4">
                        <div class="card mb-3">
                            <div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow">
                                <h3 class="h4 lh-130 mb-3 font-weight-bolder">Fitur terlengkap</h3>
                                <p class="text-muted">
                                    GajiHub memberikan solusi terbaik bagi para pemilik bisnis dengan fitur HR terlengkap dan sesuai dengan kebutuhan banyak bisnis di Indonesia.                        </p>
                                <ul class="list-unstyled">
                                    <li class="py-1">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <div class="badge badge-circle badge-primary mr-3"><img src="https://kledo.com/wp-content/themes/new-theme/assets2/img/png/check-white.png" width="14" height="14"></div>
                                            </div>
                                            <div>
                                                <p class="mb-0">
                                                    Proses payroll terintegrasi
                                                </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="py-1">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <div class="badge badge-circle badge-primary mr-3"><img src="https://kledo.com/wp-content/themes/new-theme/assets2/img/png/check-white.png" width="14" height="14"></div>
                                            </div>
                                            <div>
                                                <p class="mb-0">Pencatatan dan penghitungan PPh karyawan </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="py-1">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <div class="badge badge-circle badge-primary mr-3"><img src="https://kledo.com/wp-content/themes/new-theme/assets2/img/png/check-white.png" width="14" height="14"></div>
                                            </div>
                                            <div>
                                                <p class="mb-0">Penghitungan BPJS Ketenagakerjaan dan Kesehatan</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="py-1">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <div class="badge badge-circle badge-primary mr-3"><img src="https://kledo.com/wp-content/themes/new-theme/assets2/img/png/check-white.png" width="14" height="14"></div>
                                            </div>
                                            <div>
                                                <p class="mb-0">Manajemen cuti dan izin</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="py-1">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <div class="badge badge-circle badge-primary mr-3"><img src="https://kledo.com/wp-content/themes/new-theme/assets2/img/png/check-white.png" width="14" height="14"></div>
                                            </div>
                                            <div>
                                                <p class="mb-0">Dashboard yang mudah dimengerti </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="py-1">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <div class="badge badge-circle badge-primary mr-3"><img src="https://kledo.com/wp-content/themes/new-theme/assets2/img/png/check-white.png" width="14" height="14"></div>
                                            </div>
                                            <div>
                                                <p class="mb-0">Aplikasi mobile untuk karyawan</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="py-1">
                                        <div class="d-flex align-items-center">
                                            <div>
                                                <div class="badge badge-circle badge-primary mr-3"><img src="https://kledo.com/wp-content/themes/new-theme/assets2/img/png/check-white.png" width="14" height="14"></div>
                                            </div>
                                            <div>
                                                <p class="mb-0">Bisa terintegrasi dengan sistem akuntansi</p>
                                            </div>
                                        </div>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover">
                                    <div class="card-body pb-0">
                                        <h3 class="h4 lh-130 mb-3 font-weight-bolder">Harga terjangkau</h3>
                                        <p class="text-muted">Mulai dari 12 ribu per bulan per karyawan, para pemilik bisnis bisa mendapatkan solusi menyeluruh untuk kebutuhan payroll, HRIS, dan mampu mempermudah seluruh proses operasional SDM secara keseluruhan.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover">
                                    <div class="card-body pb-0">
                                        <h3 class="h4 lh-130 mb-3 font-weight-bolder">Mudah digunakan</h3>
                                        <p class="text-muted">
                                            Baik tim HR dan karyawan bisa menggunakan GajiHub dengan mudah
                                            tanpa perlu pelatihan khusus.
                                            Namun, jika pemilik Anda merasa kesulitan menggunakan GajiHub, tim kami juga akan membantu proses onboarding dalam menggunakan GajiHub sampai pengguna memahami secara keseluruhan.

                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover">
                                    <div class="card-body pb-0">
                                        <h3 class="h4 lh-130 mb-3 font-weight-bolder">Cocok untuk semua jenis bisnis</h3>
                                        <p class="text-muted">
                                            GajiHub bisa digunakan oleh semua jenis dan ukuran bisnis. Mulai dari UMKM sampai perusahaan multinasional. Dengan skema pembayaran per karyawan, GajiHub bisa menjadi solusi terbaik untuk mendapatkan harga yang lebih transparan.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4">
                                <div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover">
                                    <div class="card-body pb-0">
                                        <h3 class="h4 lh-130 mb-3 font-weight-bolder">Akses dari berbagai perangkat</h3>
                                        <p class="text-muted">
                                            Kini pemilik bisnis dan tim HR bisa dengan mudah memantau data karyawan, payroll, dan HRIS kapanpun dan dimanapun. Karyawan juga bisa mudah melakukan pencatatan kehadiran, pengajuan cuti, sampai melihat slip gaji hanya melalui smartphone.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center">
                            <a class="btn btn-warning rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="/daftar/"><div class="d-flex align-items-center"> <span class="ml-1 mr-2"> GABUNG SEKARANG </span> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40"> <path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path> <path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"></path> </svg></div> </a>                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="slice slice-lg bg-white py-5" data-aos="fade-up" data-aos-delay="500">
            <div class="container">
                <div class="row mb-7 justify-content-center text-center">
                    <div class="col-lg-7 py-5">
                        <h2 class="fs-1 text-break mb-3">Frequently Asked Questions</h2>
                    </div>
                </div>
                <div id="accordion-1" class="accordion accordion-spaced">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card p-2 mb-2 rounded-2 border-1 shadow">
                                <div id="heading-1-1" class="card border-0 py-4" role="button" data-toggle="collapse" data-target="#collapse-1-1" aria-expanded="false" aria-controls="collapse-1-1">
                                    <h3 class="h5 mb-0"><i class="mr-3" data-feather="file"></i>Apa itu GajiHub?</h3>
                                </div>
                                <div id="collapse-1-1" class="collapse" aria-labelledby="heading-1-1" data-parent="#accordion-1">
                                    <div class="card-body">
                                        GajiHub adalah software payroll dan HR berbasis cloud yang memiliki fitur terlengkap dan sesuai dengan kebutuhan banyak bisnis di Indonesia.
                                        <br>
                                        <br>
                                        Tidak hanya terbatas pada fitur HRIS, dengan menggunakan GajiHub, pengguna juga akan mendapatkan solusi menyeluruh untuk kemudahan pengelolaan manajemen SDM dalam bisnis.
                                    </div>
                                </div>
                            </div>
                            <div class="card p-2 mb-2 rounded-2 border-1 shadow">
                                <div id="heading-1-1" class="card border-0 py-4" role="button" data-toggle="collapse" data-target="#collapse-1-2" aria-expanded="false" aria-controls="collapse-1-2">
                                    <h3 class="h5 mb-0"><i class="mr-3" data-feather="file"></i>Apa itu program referral GajiHub?</h3>
                                </div>
                                <div id="collapse-1-2" class="collapse" aria-labelledby="heading-1-1" data-parent="#accordion-1">
                                    <div class="card-body">
                                        Sederhananya, program referral GajiHub memungkinkan Anda memperoleh komisi untuk rujukan pelanggan menggunakan kode yang Anda buat dan gunakan dalam konten seperti email, posting blog, dan webinar.
                                        <br>
                                        <br>
                                        Bergabung dengan program ini memberi Anda dan bisnis Anda cara sederhana untuk menambahkan nilai ke situs dan audiens Anda sambil menciptakan peluang pendapatan baru.
                                    </div>
                                </div>
                            </div>
                            <div class="card p-2 mb-2 rounded-2 border-1 shadow">
                                <div id="heading-1-1" class="card border-0 py-4" role="button" data-toggle="collapse" data-target="#collapse-1-3" aria-expanded="false" aria-controls="collapse-1-3">
                                    <h3 class="h5 mb-0"><i class="mr-3" data-feather="file"></i>Apakah saya harus menjadi pengguna GajiHub untuk mengikuti program ini?</h3>
                                </div>
                                <div id="collapse-1-3" class="collapse" aria-labelledby="heading-1-1" data-parent="#accordion-1">
                                    <div class="card-body">
                                        Kami akan senang jika Anda menggunakan GajiHub untuk bisnis Anda. Walaupun saat mendaftar program ini Anda diharuskan mendaftar ke akun GajiHub, tetapi Anda tidak diharuskan menjadi pelanggan GajiHub untuk menjadi bagian dari program referral GajiHub.
                                    </div>
                                </div>
                            </div>
                            <div class="card p-2 mb-2 rounded-2 border-1 shadow">
                                <div id="heading-1-1" class="card border-0 py-4" role="button" data-toggle="collapse" data-target="#collapse-1-4" aria-expanded="false" aria-controls="collapse-1-4">
                                    <h3 class="h5 mb-0"><i class="mr-3" data-feather="file"></i>Berapa komisi yang saya dapatkan per transaksi?</h3>
                                </div>
                                <div id="collapse-1-4" class="collapse" aria-labelledby="heading-1-1" data-parent="#accordion-1">
                                    <div class="card-body">
                                        Anda akan mendapatkan komisi sebesar Rp 150.000 untuk setiap penjualan berlangganan selama 3 bulan atau lebih. Sedangkan untuk prospek Anda akan mendapatkan diskon 15% jika berlangganan selama 1 tahun.
                                    </div>
                                </div>
                            </div>
                            <div class="card p-2 mb-2 rounded-2 border-1 shadow">
                                <div id="heading-1-1" class="card border-0 py-4" role="button" data-toggle="collapse" data-target="#collapse-1-5" aria-expanded="false" aria-controls="collapse-1-5">
                                    <h3 class="h5 mb-0"><i class="mr-3" data-feather="file"></i>Apakah ada minimal pencairan komisi?</h3>
                                </div>
                                <div id="collapse-1-5" class="collapse" aria-labelledby="heading-1-1" data-parent="#accordion-1">
                                    <div class="card-body">
                                        Batasan minimal pencairan nilai komisi adalah Rp1.000.000,- .
                                    </div>
                                </div>
                            </div>
                            <div class="card p-2 mb-2 rounded-2 border-1 shadow">
                                <div id="heading-1-1" class="card border-0 py-4" role="button" data-toggle="collapse" data-target="#collapse-1-6" aria-expanded="false" aria-controls="collapse-1-6">
                                    <h3 class="h5 mb-0"><i class="mr-3" data-feather="file"></i>Berapa lama komisi saya terima setelah saya mengajukan pencairan?</h3>
                                </div>
                                <div id="collapse-1-6" class="collapse" aria-labelledby="heading-1-1" data-parent="#accordion-1">
                                    <div class="card-body">
                                        Komisi akan ditransfer ke rekening Anda setiap tanggal 1 setiap bulannya, dengan minimal pencairan sebesar Rp 1.000.000,- .
                                        Apabila total komisi belum mencapai Rp 1.000.000,- maka komisi akan diakumulasikan pada bulan berikutnya, hingga mencapai minimal Rp 1.000.000,-
                                    </div>
                                </div>
                            </div>
                            <div class="card p-2 mb-2 rounded-2 border-1 shadow">
                                <div id="heading-1-1" class="card border-0 py-4" role="button" data-toggle="collapse" data-target="#collapse-1-7" aria-expanded="false" aria-controls="collapse-1-7">
                                    <h3 class="h5 mb-0"><i class="mr-3" data-feather="file"></i>Apakah ada ketentuan dan batasan dalam program referral ini?</h3>
                                </div>
                                <div id="collapse-1-7" class="collapse" aria-labelledby="heading-1-1" data-parent="#accordion-1">
                                    <div class="card-body">
                                        Baca baik-baik sebelum bergabung dengan program ini.
                                        Anda setuju bahwa Anda mengikuti aturan ini Anda bergabung dengan program referral kami. Jika tidak, Anda akan dihentikan dari program dan setuju bahwa komisi apa pun akan hangus tanpa jaminan:
                                        <ol>
                                            <li>Anda TIDAK boleh menjalankan kampanye PPC atau iframe “negatif” seperti “Penipuan nama produk / nama penulis” atau metode lain apa pun untuk menarik CTR atau rasio klik-tayang kontroversial yang dianggap orang biasa menggambarkan pandangan negatif terhadap produk. Ini menciptakan citra yang sangat buruk bagi perusahaan kami dan individu yang ditampilkan dalam produk dan Anda akan segera dihentikan dari program.</li>
                                            <li>Kami menjalankan bisnis yang sah, yang berarti bahwa kami selalu menggambarkan dan mewakili produk kami dengan benar dan fitur serta manfaatnya kepada pelanggan. Pastikan Anda melakukan hal yang sama. Siapapun yang ditemukan menggunakan klaim yang menyesatkan, informasi yang tidak akurat atau testimonial palsu akan segera dicabut akun referralnya.</li>
                                            <li>iFrame, situs ulasan, dan cloaked domains diizinkan selama tidak mengandung URL domain yang menyinggung atau negatif.</li>
                                            <li>Anda juga tidak bisa mereferensikan kode referral Anda pada diri sendiri.</li>
                                            <li>Komisi referral tidak berlaku untuk customer yang pernah terdaftar sebagai member GajiHub sebelumnya.</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="bg-theme-1">
            <div class="container-fluid py-5">
                <div class="row justify-content-center text-center">
                    <div class="col-lg-10">
                        <h2 class="fs-1 text-break mb-3 text-white">Mari tumbuh bersama dan saling menguntungkan</h2>
                        <p class="text-white mb-4">Bergabunglah dengan program referral GajiHub dan dapatkan kemudahan dari setiap kemudahan pengelolaan HRIS dalam bisnis. Mari tumbuh bersama, untung bersama.</p>
                        <div class="text-center">
                            <a class="btn btn-warning rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="/daftar/"><div class="d-flex align-items-center"> <span class="ml-1 mr-2"> GABUNG SEKARANG </span> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40"> <path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path> <path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"></path> </svg></div> </a>                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </article>
<?php get_footer() ?>