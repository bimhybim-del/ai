<?php /* Template Name: Register Template */ ?>

<?php get_header() ?>
    <article id="header" class="bg-theme-1 text-white pb-md-4 pb-lg-5 pt-lg-3">
		<div class="container pt-5 pb-5 pb-md-3">
			<h1 class="fs-1 text-break text-center mb-0">
				Daftar GajiHub Sekarang
			</h1>
			<p class="fs-6 opacity-7 text-break text-center mt-2 mb-0">
            Dapatkan aplikasi absensi beserta software payroll terlengkap!
			</p>
		</div>
	</article>

    <article>
        <div class="container py-5">
            <style>
            #registerform label.error {margin-left: 10px; width: auto;display: inline; color: red; }.pont{cursor:pointer;}
            .form-control {
                padding:1.47rem .75rem;
            }
            .custom-radio-dms label [type='radio'] {
                position: absolute;
                left: -9999px;
            }
            .custom-radio-dms [type='radio'] + div:before {
                content: '';
                border: 2px solid #4777f4;
                width: 30px;
                height: 30px;
                display: flex;
                position: absolute;
                left: 0;
                border-radius: 50%;
            }
            .custom-radio-dms :checked + div:after {
                content: '';
                transform: scale(1);
                transition: all 0.2s ease-in-out;
                width: 18px;
                height: 18px;
                background-color: #4777f4;
                border-radius: 50%;
                position: absolute;
                left: 6px;
                top: 6px;
            }
            </style>
            <form id="registerform" class="form" action="#" method="post">
                <section class="slice slice-lg">
                <div class="row">
                    <div class="col-lg-5 py-3">
                        <div class="sticky-top top-7" style="top:100px">
                            <p class="mb-2">Pilih Paket</p>


                            <div class="custom-radio-dms">
                                <?php
                                $packageId = 0;
                                if(isset($wp_query->query_vars['requests'])){
                                    $packageId = urldecode($wp_query->query_vars['requests'][0]) ?? null;
                                }
                                $args = array(
                                    'post_type'      => 'prices',
                                    'post_status'    => 'publish',
                                    'posts_per_page' => -1,
                                    'meta_key'	     => '_price_monthly',
                                    'orderby'		 => 'meta_value',
                                    'order'			 => 'DESC'
                                );
                                $prices = new WP_Query($args);
                                if ($prices -> have_posts()) {
                                    $n = 0;
                                    
                                    while ($prices -> have_posts()) {
                                        $prices->the_post();
                                        $yearly_value = get_post_meta($id, '_price_yearly', true);
                                        $monthly_value = get_post_meta($id, '_price_monthly', true);
                                        $items_value = get_post_meta($id, '_price_items', true); 
                                        $monthly_value = (int)str_replace('.', '', $monthly_value);//jadikan integer
                                        $appPlanId = 1;//jaga2
                                        if(strtolower(get_the_title()) == 'gratis'){
                                            $appPlanId = 1;
                                        }elseif(strtolower(get_the_title()) == 'pro'){
                                            $appPlanId = 2;
                                        }elseif(strtolower(get_the_title()) == 'elite'){
                                            $appPlanId = 4;
                                        }
                                        if ($monthly_value <= 14000) { // enable hanya free dan pro
                                ?>
                                <label class="card card-body">
                                    <?php
                                        
                                    ?>
                                    <input type="radio" class="option-input radio" name="plan" value="<?= $appPlanId ?>" <?= $id == $packageId || (!isset($wp_query->query_vars['requests']) && $n == 0) ? 'checked=""' : ""?>>
                                    <div class="position-relative pl-5">
                                        <p class="font-weight-bolder m-0">
                                            <?php if ($monthly_value == 0): ?>
                                                Paket <?= get_the_title() ?>
                                            <?php else: ?>
                                                Paket <?= get_the_title() ?> - Coba Gratis 14 Hari
                                            <?php endif ?>
                                        </p>
                                        <?php if ($monthly_value == 0): ?>
                                            <p class="mb-0">Gratis Selamanya</p>
                                        <?php else: ?>
                                            <p class="mb-0">Rp. <b><?=$yearly_value?></b> per bulan</p>
                                        <?php endif ?>
                                    </div>
                                </label>

                                <?php $n++;//counter while nya
                                        }
                                    }
                                } ?>
                            </div>
                        </div>
                    </div>

                <div class="col-lg-6 offset-lg-1 py-3">
                <div class="form-group"><label class="form-control-label">Nama Lengkap</label>&nbsp;
                <div class="input-group">
                <div class="input-group-prepend" style="margin-bottom: -49px;"><span class="input-group-text">
                <i data-feather="user"></i>
                </span></div>
                </div>
                <input id="register_name" class="form-control form-control-prepend" style="padding-left: 90px;" name="register_name" required="" type="text" placeholder="Nama">

                </div>
                <div class="form-group"><label class="form-control-label">Nama Perusahaan</label>&nbsp;
                <div class="input-group input-group-merge">
                <div class="input-group-prepend" style="margin-bottom: -49px;"><span class="input-group-text">
                <i data-feather="briefcase"></i>
                </span></div>
                </div>
                <input id="register_company" class="form-control form-control-prepend" style="padding-left: 90px;" name="register_company" required="" type="text" placeholder="PT. XXX">

                </div>
                <div class="form-group"><label class="form-control-label">Jabatan di perusahaan sebagai</label>&nbsp;
                <div class="input-group input-group-merge">
                <div class="input-group-prepend" style="margin-bottom: -49px;"><span class="input-group-text">
                <i data-feather="briefcase"></i>
                </span></div>
                </div>
                <input id="register_role" class="form-control form-control-prepend" style="padding-left: 90px;" name="register_role" required="" type="text" placeholder="Pemilik">

                </div>
                <div class="form-group"><label class="form-control-label">Jumlah Karyawan</label>&nbsp;
                <div class="input-group input-group-merge"><select id="employee_count" class="custom-select" name="employee_count">
                <option selected="selected" value="1">1</option>
                <option value="1">2-5</option>
                <option value="2">6-10</option>
                <option value="3">11-25</option>
                <option value="4">26-50</option>
                <option value="5">Lebih dari 50</option>
                </select></div>
                </div>
                <div class="form-group"><label class="form-control-label">Nomor HP</label>&nbsp;
                <div class="input-group input-group-merge">
                <div class="input-group-prepend" style="margin-bottom: -49px;"><span class="input-group-text">
                <i data-feather="phone"></i>
                </span></div>
                </div>
                <input id="register_phone" class="form-control form-control-prepend" style="padding-left: 90px;" name="register_phone" required="" type="text" placeholder="0812XXXX">

                </div>
                <div class="form-group"><label class="form-control-label">Email address</label>&nbsp;
                <div class="input-group input-group-merge">
                <div class="input-group-prepend" style="margin-bottom: -49px;"><span class="input-group-text">
                <i data-feather="at-sign"></i>
                </span></div>
                </div>
                <input id="register_email" class="form-control form-control-prepend" style="padding-left: 90px;" name="register_email" required="" type="email" placeholder="alamat@email.com">

                </div>

                <a href="#" id="showHideReferral">
                    <u>
                        Masukkan Kode Kupon
                    </u>
                </a>
                <div style="display: none;" id="referral_input">
                    <div class="form-group"><label class="form-control-label">Referral</label>&nbsp;
                        
                        <input id="referral" class="form-control form-control-prepend"
                            style="padding-left: 10px;" name="referral" type="text"
                            placeholder="">
                    </div>
                </div>
                    
                <div class="mt-4 text-center"><input id="registerbutton" class="btn btn-lg btn-block btn-primary" tabindex="7" type="submit" value="Daftar Sekarang"></div>
                <div class="mt-4 text-center"><small>Sudah pernah daftar?</small> <a class="small font-weight-bold" href="https://app.gajihub.com/">Login disini</a></div>
                </div>
                </div>
                </div>
                </section>
            </form>
        </div>
    </article>

    <article>
		<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--theme-1-hover)" class="overlay-bottom">
			<polygon points="0,0 100,25 100,30 0,30"/>
		</svg>
		<style>
			#jobs .card .rounded-circle {
				width: 50px;
				height: 50px;
			}
			#jobs .card h3 {
				width: calc(100% - 50px - 1rem);
			}
		</style>
	</article>
    <!-- Core JS  -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"
        integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg=="
        crossorigin="anonymous"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.3/js/bootstrap.bundle.min.js"
        integrity="sha512-iceXjjbmB2rwoX93Ka6HAHP+B76IY1z0o3h+N1PeDtRSsyeetU3/0QKJqGyPJcX63zysNehggFwMC/bi7dvMig=="
        crossorigin="anonymous"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/svg-injector/1.1.3/svg-injector.min.js"
        integrity="sha512-LpKoEmPyokcDYSjRJ/7WgybgdAYFsKtCrGC9m+VBwcefe1vHXyUnD9fTQb3nXVJda6ny1J84UR+iBtEYm3OQmQ=="
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"
        integrity="sha512-A7AYk1fGKX6S2SsHywmPkrnzTZHrgiVT7GcQkLGDe2ev0aWb8zejytzS8wjo7PGEXKqJOrjQ4oORtnimIRZBtw=="
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.28.0/feather.min.js"
        integrity="sha512-7x3zila4t2qNycrtZ31HO0NnJr8kg2VI67YLoRSyi9hGhRN66FHYWr7Axa9Y1J9tGYHVBPqIjSE1ogHrJTz51g=="
        crossorigin="anonymous"></script>
    <script>
        AOS.init({
            once: true
        });
        feather.replace()
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <script>
jQuery(function($) {

$( document ).ready(function () {
   var cookie = getCookie('kledo_referral');
   $("#referral").val(cookie);
});

$('#showHideReferral').click(function (event) {
   event.preventDefault();
   showHideReferral();
});
	
function showHideReferral() {
    var x = document.getElementById("referral_input");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
              x.style.display = "none";
           }
    }
	
$.validator.addMethod("mobile_phone", function (value, element) {
    return /^08/.test(value);
});

$.validator.addMethod("company_name", function (value, element) {
    return /^[a-zA-Z0-9\.\- ]*$/.test(value);
});

    $("#register_email").keyup(function(){
        $(this).val($(this).val().toLowerCase());
    });

    $("#registerform").validate({
			rules: {
				register_name: {
					required: true,
					minlength: 5
				},
				register_role: {
					required: true,
					minlength: 3
				},
				register_company: {
					required: true,
					minlength: 5,
					company_name: true
				},
				register_email: {
					required: true,
					email: true,
					minlength: 7
				},
				register_phone: {
					required: true,
					minlength: 7,
					digits: true,
					mobile_phone: true
				}
			},
			messages: {
				register_name: {
					required: "Silakan masukkan nama lengkap Anda",
					minlength: "Nama minimal 5 huruf"
				},
				register_role: {
					required: "Silakan masukkan jabatan Anda di perusahaan",
					minlength: "Jabatan minimal 3 huruf"
				},
				register_company: {
					required: "Silakan masukkan nama perusahaan Anda",
					minlength: "Nama perusahaan minimal 5 huruf",
					company_name: "Nama perusahaan tidak valid"
				},
				register_email: {
					required: "Silakan masukkan alamat email Anda",
					minlength: "Alamat email minimal 7 huruf",
					email: "Silakan isikan format alamat email yang benar. Contoh: namaku@gmail.com"
				},
				register_phone: {
					required: "Silakan masukkan nomor telepon Anda",
					minlength: "Nomor telepon minimal 7 angka",
					digits: "Hanya angka yang diperbolehkan dalam nomor telepon",
					mobile_phone: "Nomor HP yang diperbolehkan hanya berawalan 08"
				},
			},
            submitHandler: function(form) {
                doSubmit();
            }
		});
	function getCookie(cname) {
      var name = cname + "=";
      var decodedCookie = decodeURIComponent(document.cookie);
      var ca = decodedCookie.split(';');
      for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    function doSubmit(){
        $("#registerbutton").val("Mohon tunggu ...").attr("disabled", true);
        var query = {
            name: $("#register_name").val(),
            role: $("#register_role").val(),
            property_name: $("#register_company").val(),
            email: $("#register_email").val(),
            phone_number: $("#register_phone").val(),
            plan_id: $("input[name='plan']:checked").val(),
            referral: $("#referral").val(),
            employee_count: $("#employee_count").val(),
            app: 'hr'
        };
        
        // var uriRegistration = "https://register.api.kledo.com/api/v1/tenants/register";//dulu pake ini
        var uriRegistration = "https://register.api.kledo.com/api/v1/tenants/register/withCheckingAppConnection";//kalo prodcution pake ini 
        // var uriRegistration = "https://app.kledo.test/api/v1/tenants/register/withCheckingAppConnection";//untuk dev lokal
        $.ajax({
            url: uriRegistration, 
            type: 'post',
            dataType: 'JSON',
            data: query
        })
        .done(function( data ) {
            if(query.plan_id == 1){
                //kalo ini paket gratis
                window.location.href="/daftar-free-berhasil";
            }else{
                //lari ke bagian paket non gratis
                window.location.href="/daftar-berhasil";
            }
        })
        .fail(function( $xhr ) {
            var response = $xhr.responseJSON;
            let returnMessage = response.message + `<br/><br>
                Silahkan <a href="https://app.gajihub.com">klik disini</a>
                untuk login.
                <br/>
                Jika Anda lupa password, silahkan <a href="https://app.gajihub.com/user/forgot">klik disini</a> 
                untuk mereset password Anda.
            `;
            Swal.fire({
                title: 'Gagal',
                icon:'warning',
                html:returnMessage,
                showConfirmButton: true,
            })
            // alert(response.message);
            $("#registerbutton").val("Daftar Sekarang").attr("disabled", false);
        });
        return false;
    }
});
</script>



</body>
<script>
     $(document).ready(function () {
            var monthly_tab = document.getElementById("tab_monthly");
            var yearly_tab = document.getElementById("tab_yearly");
            var monthly_tab2 = document.getElementById("tab_monthly2");
            var yearly_tab2 = document.getElementById("tab_yearly2");
            
            // =================== price changes only  javascript used 
            var e = document.getElementById("filt-monthly"),
                d = document.getElementById("filt-yearly"),
                t = document.getElementById("switcher");
                
            e.addEventListener("click", function () {
                t.checked = false;
                e.classList.add("toggler--is-active");
                d.classList.remove("toggler--is-active");
                monthly_tab.classList.remove("d-none");
                yearly_tab.classList.add("d-none");
                monthly_tab2.classList.remove("d-none");
                yearly_tab2.classList.add("d-none");
        
            });

            d.addEventListener("click", function () {
                yearly_tab.classList.add("d-none");
                t.checked = true;
                d.classList.add("toggler--is-active");
                e.classList.remove("toggler--is-active");
                monthly_tab.classList.add("d-none");
                yearly_tab.classList.remove("d-none");
                monthly_tab2.classList.add("d-none");
                yearly_tab2.classList.remove("d-none");
            });

            t.addEventListener("click", function () {
                d.classList.toggle("toggler--is-active");
                e.classList.toggle("toggler--is-active");
                yearly_tab.classList.toggle("d-none");
                monthly_tab.classList.toggle("d-none");
                yearly_tab2.classList.toggle("d-none");
                monthly_tab2.classList.toggle("d-none");
            });
        });
</script>
<?php get_footer() ?>