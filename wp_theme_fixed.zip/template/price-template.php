<?php /* Template Name: Price Template */ ?>

<?php $homepage = get_option('homepage_section'); ?>
<?php get_header() ?>

	<article id="header" class="bg-theme-1 text-white pt-lg-3">
		<div class="container pt-5 pb-5 pb-md-3">
			<div class="row">
				<div class="col-12 col-md-11 col-lg-10 col-xl-9 mx-auto">
					<h1 class="fs-1 text-break text-center mb-0">
						Semua fitur hebat GajiHub Gratis!
					</h1>
					<p class="fs-6 opacity-7 text-break text-center mt-2 mb-0 mx-md-5">
						Mulai dari payroll, absensi, reimbursement, kelola pph 21, kelola bpjs hinggal ESS semua ada.
					</p>
				</div>
			</div>
		</div>
	</article>

	<article class="bg-theme-1 position-relative">
		<div class="container pt-5 pb-3">
			<div class="px-xl-5 mx-xl-3">
				<div class="d-flex justify-content-center font-title mb-5 pb-3 pricing-switch">
					<div class="d-flex bg-white rounded-pill shadow p-2">
						<button type="button" class="btn btn-clear fs-6 position-relative pointer-events-none" onclick="switchPrice('.pricing-switch','.pricing')">
							<span>per <b>Tahun</b></span>
							<div class="position-absolute top left right mt-n4">
								<span class="badge badge-success text-white rounded-pill p-2">10%</span>
							</div>
						</button>
						<div class="custom-control custom-switch custom-switch-lg switch-always-on switch-overlay ml-2" onclick="switchPrice('.pricing-switch','.pricing')">
							<input type="checkbox" class="custom-control-input" id="switchPricing">
							<label class="custom-control-label" for="switchPricing">
								<span class="sr-only">Switch Pricing</span>
							</label>
						</div>
						<button type="button" class="btn btn-clear fs-6" onclick="switchPrice('.pricing-switch','.pricing')">
							<span class="opacity-5">per <b>Bulan</b></span>
						</button>
					</div>
				</div>
				<div class="row no-gutters pricing">
					<?php
                    $args = array(
                        'post_type' => 'prices',
                        'post_status' => 'publish',
                        'posts_per_page' => -1
                    );
                    $prices = new WP_Query($args);
                    if ($prices -> have_posts()) {
                        $n = 0;
                        while ($prices -> have_posts()) {
                            $n++;
                            $add_classes = [
                                '',
                                'mt-md-4 pt-md-2',
                                'index-1',
                                'mt-md-4 pt-md-2'
                            ];
                            $add_classes_2 = [
                                '',
                                'rounded-right-md-0 index-1',
                                'index-2',
                                'rounded-left-md-0 index-1'
                            ];
                            $id = get_the_ID();
                            $prices->the_post();
                            $yearly_value = get_post_meta($id, '_price_yearly', true);
                            $monthly_value = get_post_meta($id, '_price_monthly', true);
							$detectMonthlyValue = (int)str_replace('.', '', $monthly_value);//jadikan integer
                            $items_value = get_post_meta($id, '_price_items', true);
                            $class_text = get_post_meta($id, '_class_text', true); ?>
					<div class="col-md-4 mb-4 pb-2 <?=$add_classes[$n]?>">
						<div class="card bg-white border-0 rounded-3 <?=$add_classes_2[$n]?> shadow text-center text-break">
							<div class="card-body py-4 px-lg-4">
								<h3 class="fs-5 lh-2 text-uppercase font-title font-weight-bold my-2">
									<?php the_title() ?>
								</h3>
								<div class="font-title mt-3 mb-4">
									<div class="fs-1 d-flex align-items-center justify-content-center text-<?=$class_text?> lh-2 mr-4 mr-lg-0 mr-xl-4 pr-2 pr-md-3">
										<span class="fs-4 opacity-2 text-dark mb-1 mr-1">Rp</span>
										<b><?= $yearly_value ?></b>
										<b class="d-none"><?= $monthly_value ?></b>
									</div>
									<div class="opacity-3"><?php the_content() ?></div>
								</div>
								<div class="separator my-3 mx-auto w-75"></div>
								<ul class="list-group list-group-flush lh-2 mb-0">
									<?php foreach ($items_value as $item): ?>
									<li class="list-group-item bg-transparent border-0 py-2 px-0"><?=$item?></li>
									<?php endforeach ?>
									<li class="list-group-item bg-transparent border-0 py-2 px-0 d-none d-md-block">&nbsp;</li>
								</ul>
								<?php 
                                if ($detectMonthlyValue <= 14000) {
                                    ?>
									<?php
										if($id != 33 && $id != 34){
									?>
										<!-- Untuk Free -->
										<a class="btn btn-warning rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="<?= $homepage['homepage_hero_trial_url'] ?>?requests[]=<?=get_the_ID()?>">
											<div class="d-flex align-items-center">
												<span class="ml-1 mr-2">
													Daftar
												</span>
												<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
													<path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path>
													<path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"></path>
												</svg>
											</div>
										</a>
										<!-- End Untuk Free-->
									<?php }else if($id == 34){ ?>
										<!--<strong>Coming Soon!</strong>-->
										<!-- Untuk Pro -->
											<a class="btn btn-danger rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="<?= $homepage['homepage_hero_trial_url'] ?>?requests[]=<?=get_the_ID()?>">
											<div class="d-flex align-items-center">
												<span class="ml-1 mr-2">
													Daftar
												</span>
												<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
													<path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path>
													<path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"></path>
												</svg>
											</div>
										</a>
										<!-- -->
									<?php }elseif($id == 33){ ?>
										<!-- Untuk Elite -->
											<a class="btn btn-info rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="<?= $homepage['homepage_hero_trial_url'] ?>?requests[]=<?=get_the_ID()?>">
											<div class="d-flex align-items-center">
												<span class="ml-1 mr-2">
													Daftar
												</span>
												<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
													<path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path>
													<path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"></path>
												</svg>
											</div>
										</a>
										<!-- Elite -->

								<?php 
									} 
								}
								?>
							</div>
							<div class="card-footer bg-<?=$class_text?> w-25 border-0 rounded-3 py-1 mt-2 mb-4 mx-auto"></div>
						</div>
					</div>
					<?php
                                // Or your video player code here
                        }
                    }
                    wp_reset_query();
                    ?>
				</div>
			</div>
		</div>
		<div class="position-absolute left right" style="bottom:200px">
			<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-bottom">
				<polygon points="0,0 100,25 100,30 0,30"/>
			</svg>
		</div>
		<div class="position-absolute left right bg-white overlay-bottom" style="height:205px"></div>
	</article>
<?php
while (have_posts()):
    the_post();
    the_content();
endwhile;
?>

<?php get_footer() ?>
