<?php /* Template Name: Solution Template */ ?>

<?php get_header() ?>

<?php 
if(have_posts()): 
	while(have_posts()): 
	the_post();
	$id = get_the_ID();
	$tagline = get_post_meta($id, '_tagline', true);
	$button_text = get_post_meta($id, '_button_text', true);
	$button_url = get_post_meta($id, '_button_url', true);
?>

	<article id="header">
		<script>
			document.querySelectorAll('.navbar-dark').forEach(nav => {
				nav.classList.add('navbar-light')
				nav.classList.remove('navbar-dark')
			})
		</script>
		<div class="container pt-5 pb-5 pb-md-3">
			<div class="row">
				<div class="col-12 col-md-11 col-lg-10 col-xl-9 mx-auto">
					<h1 class="fs-1 text-break text-center mb-0">
						<?= get_the_title() ?>
					</h1>
					<p class="fs-6 opacity-7 text-break text-center mt-2 mb-0 mx-md-5">
						<?= $tagline ?>
					</p>
					<div class="text-center my-4">
						<a class="btn btn-danger rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap" href="<?=$button_url?>">
							<div class="d-flex align-items-center">
								<span class="ml-1 mr-2">
									<?= $button_text ?>
								</span>
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
									<path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"/>
									<path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"/>
								</svg>
							</div>
						</a>
					</div>
				</div>
			</div>
		</div>
	</article>

    <?php the_content() ?>
    
<?php endwhile; endif ?>
<?php get_footer() ?>