<?php /* Template Name: Proposal Template */ ?>

<?php get_header() ?>

<script>
document.querySelector('header').style.display = 'none'
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>


	<article class="bg-theme-1 position-relative">
		<style>
			body {
				padding-top: 0;
			}
		</style>
		<div class="container py-4 py-md-5">
			<div class="row pb-md-5 pb-lg-0">
				<div class="col-md order-md-2 index-1">
					<div class="d-flex justify-content-center justify-content-md-start">
						<a class="navbar-brand d-flex align-items-center text-break ws-init lh-1 mr-0 mt-md-3 mb-4" href="<?= get_site_url() ?>">
							<img width="40" height="40" src="<?= get_template_directory_uri() ?>/assets/img/gajihub-logo-color.svg" alt="Logo">
							<span class="sr-only">GajiHub</span>
						</a>
					</div>
					<h1 class="fs-1 text-white text-break text-center text-md-left mb-0">
						Kenali Fitur GajiHub Secara Lengkap dalam 1 Menit
					</h1>
					<p class="fs-6 opacity-7 text-white text-break text-center text-md-left mt-2 mb-0">
						Kesulitan dalam mengelola pembukuan dan proses operasional bisnis? Mari mengenal lebih jauh fitur terbaik dari GajiHub dan cari tahu apa yang bisa GajiHub lakukan untuk membuat bisnis Anda menjadi lebih baik.
					</p>
					<div class="text-center text-md-left my-4">
						<a type="button" class="btn btn-warning rounded-pill text-uppercase" data-toggle="modal"
                           data-target="#modal-notif" role="button" download="Proposal GajiHub" href="#">
							<div class="d-flex align-items-center">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32">
									<path fill="#292D32" opacity=".25" d="M22 10.7599C22 10.2899 21.62 9.8999 21.14 9.8999H2.86C2.38 9.8999 2 10.2799 2 10.7599C2 16.6499 6.11 20.7599 12 20.7599C17.89 20.7599 22 16.6399 22 10.7599Z"/>
									<path fill="#fff" d="M12.4598 15.9L15.3098 13.06C15.5998 12.77 15.5998 12.29 15.3098 12C15.0198 11.71 14.5398 11.71 14.2498 12L12.6898 13.56V3.98999C12.6898 3.57999 12.3498 3.23999 11.9398 3.23999C11.5298 3.23999 11.1898 3.57999 11.1898 3.98999V13.56L9.61984 12C9.32984 11.71 8.84984 11.71 8.55984 12C8.40984 12.15 8.33984 12.34 8.33984 12.53C8.33984 12.72 8.40984 12.91 8.55984 13.06L11.4098 15.9C11.6998 16.2 12.1698 16.2 12.4598 15.9Z"/>
								</svg>
								<span class="fs-7 mx-2">
									Unduh <b>Proposal</b>
								</span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-md-6 col-lg-5 order-md-1 index-1 text-center">
					<img class="img-fluid ml-n4 ml-md-0" width="400" height="600" src="<?= get_template_directory_uri() ?>/assets/img/proposal-logo.png">
				</div>
			</div>
		</div>
		<div class="position-absolute left right" style="bottom:150px">
			<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-bottom">
				<polygon points="0,0 100,25 100,30 0,30"/>
			</svg>
		</div>
		<div class="position-absolute left right bg-white overlay-bottom" style="height:155px"></div>
	</article>

	<article>
		<div class="container mb-5 mt-md-n5">
			<div class="row">
				<div class="col-md offset-md-6 offset-lg-5 mt-md-n5">
					<h2 class="fs-2 text-break text-center text-md-left mb-0">
						Platform yang tepat untuk membuat bisnis menjadi lebih hebat
					</h2>
					<p class="fs-6 opacity-7 text-break text-center text-md-left mt-2 mb-0">
						Efisiensi dan adaptasi dalam bisnis adalah langkah terpenting untuk membuat proses yang berkelanjutan. Dengan mengetahui semua fitur terbaik di software akuntansi GajiHub, Anda telah selangkah lebih maju untuk membuat seluruh proses operasi bisnis berjalan lebih optimal.
					</p>
				</div>
			</div>
		</div>
	</article>

    <!-- Modal -->
    <div class="modal fade" id="modal-notif" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form id="subscribeForm">
                <input type="hidden" name="form" value="proposal" />
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Download Proposal</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div id="modal-body-content">
                            Isikan data Anda untuk mendownload proposal GajiHub
                            <br />
                            <div class="form-group" style="margin-top: 20px;">
                                <input type="text" class="form-control" id="input_app_id" required name="app_id" value="2" hidden>
                            </div>
                            <div class="form-group" style="margin-top: 20px;">
                                <input type="text" class="form-control" id="inputname" required name="name" placeholder="Nama">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" id="inputemail" required name="email" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="inputcompany" required name="company" placeholder="Nama Perusahaan">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="inputphone" required name="phone" placeholder="Nomor Whatsapp">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="submitButton" class="btn btn-warning btn-lg btn-block">Download</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<script>
    $(document).ready(function(){
        $('#modal-notif').on('shown.bs.modal', function () {
            $("#subscribeForm input:text").first().focus();
        })

        $("#subscribeForm").submit(function(e){
            submitForm();
            return false;
        });
    });


    function submitForm(){
        $.ajax({
            type: "POST",
            url: "https://register.api.kledo.com/api/v1/mailers",
            cache:false,
            data: $('#subscribeForm').serialize(),
            dataType: 'json',
            success: function(response){
                $("#modal-body-content").html(response.data.body);
                $(".modal-footer").hide();
            },
            error: function(){
                alert("Gagal. Mohon kontak hello@kledo.com untuk informasi lebih lanjut.");
            }
        });
    }
</script>
<?php get_footer() ?>