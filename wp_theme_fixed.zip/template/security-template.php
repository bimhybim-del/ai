<?php /* Template Name: Security Template */ ?>

<?php get_header() ?>
    <article id="header" class="pb-md-4">
		<script>
			document.querySelectorAll('.navbar-dark').forEach(nav => {
				nav.classList.add('navbar-light')
				nav.classList.remove('navbar-dark')
			})
		</script>
		<section class="parallax text-white" data-parallax="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/safe.webp">
			<div class="container py-5 d-flex align-items-center justify-content-center flex-column">
				<div class="row w-100">
					<div class="col-12 col-md-11 col-lg-10 col-xl-9 mx-auto">
						<h1 class="fs-1 text-break text-center mb-0">
                            Keamanan di GajiHub
						</h1>
						<p class="fs-6 opacity-5 text-break text-center mt-2 mb-0 mx-md-5">
                            Demi menjaga keamanan setiap data Anda, kami tidak pernah beristirahat. Kami telah membangun langkah-langkah keamanan terbaik dan preventif ke dalam sistem kami untuk memastikan Anda dapat menggunakan GajiHub dengan aman.
						</p>
                        <footer class="blockquote-footer font-italic font-weight-bolder text-white text-center mt-5">Ogi Sigit, CEO GajiHub</footer>
					</div>
				</div>
			</div>
			<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-bottom">
				<polygon points="100,30 0,30 0,0 50,25 100,0"/>
			</svg>
		</section>
		<style>
			#header .container {
				min-height: 70vh;
			}
			#header .parallax:after {
				background-color:rgba(0,0,0,.75)
			}
			@media (min-width: 992px) {
				#header h1 {
					font-size: calc(2rem + 1.75vw) !important;
				}
				#header .parallax:after {
					background-color: transparent;
					background-image: linear-gradient(90deg,rgba(0,0,0,.8) 0,rgba(0,0,0,.6) 45%,transparent 100%)
				}
			}
		</style>
		<script>
			document.addEventListener('DOMContentLoaded', function() {
				function scrollParallax(id,overscroll) {
					document.querySelectorAll(id).forEach(selector => {
						let element = selector.id
							slot = document.querySelector('slot')

						let desktop = document.createElement('style')
							desktop.id = element + '-css'
						slot.appendChild(desktop)

						let mobile = document.createElement('style')
							mobile.id = element + '-css-mobile'
							mobile.innerText = '@media (max-width:991px){#' + element + ' .parallax:before{background-size:cover!important;background-position-y:initial!important}}'
						slot.appendChild(mobile)

						function startEffect() {
							let scroll = window.pageYOffset || document.documentElement.scrollTop
								item = document.querySelector('#' + element).clientHeight
							if ( scroll <= (item + overscroll) ) {
								document.querySelector('#' + element + '-css').innerText = '#' + element + ' .parallax:before{background-size:calc(100vmax + ' + scroll + 'px);background-position-y: -' + (scroll + (scroll / 2)) + 'px}'
							}
						}

						if ( document.body.clientWidth >= 992 ) {
							startEffect()
							window.onscroll = () => {
								startEffect()
							}
						}
					})
				}
				scrollParallax('#header',0)
			})
		</script>
	</article>

	<article>
		<div class="container py-5">
			<div class="row mb-5">
				<div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
                    <p class="text-center">
                        Gajihub menyadari setiap informasi merupakan bagian penting dari setiap bisnis, sehingga kami menjamin keamanan data setiap pelanggan. Kami juga bertanggung jawab secara serius atas keamanan yang diperoleh pelanggan. Selain itu, keamanan dan kemudahan dari penggunaan software, sistem, dan data menjadi prioritas utama kami. Keamanan juga menjadi kunci dari penawaran yang kami berikan. Untuk itu semua informasi yang Anda berikan telah ter-encrypt dan terjaga dengan teknologi dan keamanan yang terkemuka.
                    </p>
				</div>
			</div>
            <div class="row mb-5">
                <div class="col-12">
                    <h2 class="fs-2 text-break mb-3 text-center">
						Mengapa GajiHub Aman?
					</h2>
                </div>
            </div>
			<div class="row text-center hover-card">
				<div class="col-12 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="200" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/svg/icons/iso27001.png" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Berstandar Internasional ISO/IEC 27001</h3>
							<p class="opacity-5 text-break">ISO/IEC 27001 adalah standar internasional yang menetapkan spesifikasi untuk sistem manajemen keamanan informasi atau Information Security Management System (ISMS). Kini Anda tidak perlu khawatir kehilangan atau pencurian data penting saat menggunakan Gajihub. Gajihub mengelola dan mengendalikan serta menjaga risiko keamanan informasi data Anda, dan selalu memastikan kerahasiaan (confidentiality), integritas (integrity) dan ketersediaan (availability) data Anda berdasarkan standar ISO/IEC 27001.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/svg/icons/hdd.svg" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Keamanan Transmisi Data</h3>
							<p class="opacity-5 text-break">Seluruh informasi antara pengguna dan Gajihub telah terenkripsi dengan SSL 256 bytes. Enkripsi membuat kebocoran data saat komunikasi terjadi menjadi tidak memungkinkan. Sehingga data yang dimiliki pelanggan aman dari pencurian dengan cara decryption.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/svg/icons/folder.svg" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Isolasi Data</h3>
							<p class="opacity-5 text-break">Kami menyimpan data pelanggan dalam database terpisah. Setiap data pelanggan terpisah antara satu dengan yang lainnya menggunakan perangkat kerja yang aman. Dengan begitu, data pelanggan tidak akan bisa diakses oleh pelanggan lainnya. Kami menjamin keamanann data pelanggan dan tidak akan membagikan kepada pihak ketiga tanpa persetujuan pengguna yang bersangkutan.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/svg/icons/server.svg" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Keamanan Server</h3>
							<p class="opacity-5 text-break">Gajihub menggunakan server Amazon Web Services (AWS) yang merupakan Cloud Infrastructure as a Services paling dipercaya di dunia. Server Gajihub terletak di pusat data terdepan. Datacenter kami menggunakan kontrol akses biometrik, pengawasan konstan, kapasitas daya dan generator yang besar, dapat mencegah kebakaran, dan pemantauan iklim secara cermat untuk melindungi server penyimpanan data pelanggan.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/svg/icons/sharing.svg" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Kontrol Siapa Melihat Apa</h3>
							<p class="opacity-5 text-break">Pengguna memiliki kontrol penuh terhadap data yang mereka miliki. Setiap orang yang Anda undang harus membuat kata sandi yang unik dan tidak ada yang bisa melihatnya, termasuk dari pihak Gajihub sendiri. Tidak ada yang dapat melihat data pengguna, kecuali pengguna yang mengundangnya. Selain itu, Gajihub menawarkan tingkatan izin yang memungkinkan pengguna membatasi hak akses atas data yang dimilikinya.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/svg/icons/uploading.svg" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Informasimu Disimpan Online secara aman</h3>
							<p class="opacity-5 text-break">Dengan sistem berbasis cloud, Anda tidak perlu khawatir dengan keamanan data ketika komputer rusak ataupun hilang karena semua data dapat dibackup dan disimpan secara otomatis di cloud. Selain itu, Gajihub juga memungkinan Anda untuk login di perangkat lain asalkan masih terhubung ke internet.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/svg/icons/laporan-keuangan.svg" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Update Rutin & Inovasi</h3>
							<p class="opacity-5 text-break">Tim Gajihub akan terus melakukan inovasi dengan menghadirkan fitur-fitur baru dan peningkatan kinerja. Pembaruan dilakukan tanpa mengganggu layanan dan juga aktivitas pengguna.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/svg/icons/secure-file.svg" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Kami Mementingkan Privasi Seperti Anda</h3>
							<p class="opacity-5 text-break">Gajihub selalu mementingkan privasi Anda dalam setiap aktivitas yang kami lakukan. Untuk itu kami mengikuti serangkaian pedoman dan praktik yang ketat untuk melindungi semua informasi pribadi pelanggan. Gajihub tidak menjual, menyewakan, atau berbagi imformasi dengan pihak ketiga untuk melakukan promosi. Untuk informasi lebih lanjut, Anda bisa membaca Pernyataan Privasi kami.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/svg/icons/safe-payment.svg" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Security Monitoring</h3>
							<p class="opacity-5 text-break">Tim keamanan Gajihub terus memantau sistem keamanan, log peristiwa, pemberitahuan, dan peringatan dari semua sistem untuk mengidentifikasikan dan mengelola ancaman yang dapat menyerang secara tiba-tiba.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</article>
    <article>
		<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--theme-1-hover)" class="overlay-bottom">
			<polygon points="0,0 100,25 100,30 0,30"/>
		</svg>
		<style>
			#jobs .card .rounded-circle {
				width: 50px;
				height: 50px;
			}
			#jobs .card h3 {
				width: calc(100% - 50px - 1rem);
			}
		</style>
	</article>
<?php get_footer() ?>