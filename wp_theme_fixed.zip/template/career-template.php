<?php /* Template Name: Career Template */ ?>

<?php get_header() ?>

	<article id="header" class="pb-md-4">
		<script>
			document.querySelectorAll('.navbar-dark').forEach(nav => {
				nav.classList.add('navbar-light')
				nav.classList.remove('navbar-dark')
			})
		</script>
		<section class="parallax text-white" data-parallax="https://images.unsplash.com/photo-1586227740560-8cf2732c1531?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1280&q=80">
			<div class="container py-5 d-flex align-items-center justify-content-center flex-column">
				<div class="row w-100">
					<div class="col-12 col-md-11 col-lg-10 col-xl-9 mx-auto">
						<h1 class="fs-1 text-break text-center mb-0">
							Berkarir di GajiHub
						</h1>
						<p class="fs-6 opacity-5 text-break text-center mt-2 mb-0 mx-md-5">
							Wujudkan Masa Depan Cemerlangmu
						</p>
					</div>
				</div>
			</div>
			<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-bottom">
				<polygon points="100,30 0,30 0,0 50,25 100,0"/>
			</svg>
		</section>
		<style>
			#header .container {
				min-height: 70vh;
			}
			#header .parallax:after {
				background-color:rgba(0,0,0,.75)
			}
			@media (min-width: 992px) {
				#header h1 {
					font-size: calc(2rem + 1.75vw) !important;
				}
				#header .parallax:after {
					background-color: transparent;
					background-image: linear-gradient(90deg,rgba(0,0,0,.8) 0,rgba(0,0,0,.6) 45%,transparent 100%)
				}
			}
		</style>
		<script>
			document.addEventListener('DOMContentLoaded', function() {
				function scrollParallax(id,overscroll) {
					document.querySelectorAll(id).forEach(selector => {
						let element = selector.id
							slot = document.querySelector('slot')

						let desktop = document.createElement('style')
							desktop.id = element + '-css'
						slot.appendChild(desktop)

						let mobile = document.createElement('style')
							mobile.id = element + '-css-mobile'
							mobile.innerText = '@media (max-width:991px){#' + element + ' .parallax:before{background-size:cover!important;background-position-y:initial!important}}'
						slot.appendChild(mobile)

						function startEffect() {
							let scroll = window.pageYOffset || document.documentElement.scrollTop
								item = document.querySelector('#' + element).clientHeight
							if ( scroll <= (item + overscroll) ) {
								document.querySelector('#' + element + '-css').innerText = '#' + element + ' .parallax:before{background-size:calc(100vmax + ' + scroll + 'px);background-position-y: -' + (scroll + (scroll / 2)) + 'px}'
							}
						}

						if ( document.body.clientWidth >= 992 ) {
							startEffect()
							window.onscroll = () => {
								startEffect()
							}
						}
					})
				}
				scrollParallax('#header',0)
			})
		</script>
	</article>

	<article>
		<div class="container py-5">
			<div class="row mb-4">
				<div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
					<h2 class="fs-2 text-break mb-3 text-center">
						Mengapa Berkarir di GajiHub?
					</h2>
				</div>
			</div>
			<div class="row text-center hover-card">
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="<?= get_template_directory_uri() ?>/upload/icon-10.png" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Adrenalin Startup</h3>
							<p class="opacity-5 text-break">Rasakan bekerja dalam lingkungan startup penuh dengan semangat dan adrenalin tinggi. Kami bukan sekedar bekerja, tapi kami seniman yang membuat karya, mencarikan solusi bagi jutaan UMKM di Indonesia.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="<?= get_template_directory_uri() ?>/upload/icon-11.png" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Fully Remote</h3>
							<p class="opacity-5 text-break">100% karyawan GajiHub bekerja secara remote, karena kami sadar bukan kehadiranmu yang dibutuhkan, tapi karya, pikiran dan kemampuanmu. Kami membuktikan bekerja dari manapun lebih efektif daripada terpaksa datang setiap pagi ke kantor. Win-win solution!</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="<?= get_template_directory_uri() ?>/upload/icon-12.png" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Teknologi Terbaru</h3>
							<p class="opacity-5 text-break">Berkarir di GajiHub, berarti kamu akan menggunakan metode-metode terbaru, teknologi-teknologi terbaru. Dapatkan pengalaman yang tak akan didapatkan dengan bekerja di perusahaan konvensional.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 mx-auto mb-4 pb-md-3">
					<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
						<div class="card-body">
							<img class="mb-3" loading="lazy" width="100" height="100" src="<?= get_template_directory_uri() ?>/upload/icon-13.png" alt="Icon">
							<h3 class="fs-4 text-break mb-3">Bagian Penting</h3>
							<p class="opacity-5 text-break">Di GajiHub, kamu akan bekerja di dalam tim-tim kecil yang super agile. Dalam tim kecil, berarti setiap detik karyamu sangat dinanti dan dihargai. Kamu akan menjadi bagian penting dari perkembangan GajiHub.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</article>

	<article class="bg-light text-center text-md-left py-md-5">
		<div class="container py-5 position-relative">
			<div class="row">
				<div class="col-md-8">
					<h2 class="fs-2 text-break mb-3">
						Pilih Peluang Karir Sesuai Bidangmu
					</h2>
					<p class="fs-6 opacity-6 mb-3 pb-1">
						Kirimkan lamaran kamu beserta Curriculum Vitae dan foto terbaru ke <strong>hr@gajihub.com</strong> atau menghubungi via WhatsApp ke nomor di bawah
					</p>
					<a class="btn btn-success rounded-pill py-2 pl-3 pr-4 lh-1 fs-6 font-title text-uppercase ws-nowrap" href="https://wa.me/6281222800070&text=Hallo, Saya mau tanya tentang GajiHub.">
						<div class="d-flex align-items-center">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="30" height="30" fill="currentColor" class="m-1">
								<path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2M12.05 3.67C14.25 3.67 16.31 4.53 17.87 6.09C19.42 7.65 20.28 9.72 20.28 11.92C20.28 16.46 16.58 20.15 12.04 20.15C10.56 20.15 9.11 19.76 7.85 19L7.55 18.83L4.43 19.65L5.26 16.61L5.06 16.29C4.24 15 3.8 13.47 3.8 11.91C3.81 7.37 7.5 3.67 12.05 3.67M8.53 7.33C8.37 7.33 8.1 7.39 7.87 7.64C7.65 7.89 7 8.5 7 9.71C7 10.93 7.89 12.1 8 12.27C8.14 12.44 9.76 14.94 12.25 16C12.84 16.27 13.3 16.42 13.66 16.53C14.25 16.72 14.79 16.69 15.22 16.63C15.7 16.56 16.68 16.03 16.89 15.45C17.1 14.87 17.1 14.38 17.04 14.27C16.97 14.17 16.81 14.11 16.56 14C16.31 13.86 15.09 13.26 14.87 13.18C14.64 13.1 14.5 13.06 14.31 13.3C14.15 13.55 13.67 14.11 13.53 14.27C13.38 14.44 13.24 14.46 13 14.34C12.74 14.21 11.94 13.95 11 13.11C10.26 12.45 9.77 11.64 9.62 11.39C9.5 11.15 9.61 11 9.73 10.89C9.84 10.78 10 10.6 10.1 10.45C10.23 10.31 10.27 10.2 10.35 10.04C10.43 9.87 10.39 9.73 10.33 9.61C10.27 9.5 9.77 8.26 9.56 7.77C9.36 7.29 9.16 7.35 9 7.34C8.86 7.34 8.7 7.33 8.53 7.33Z"/>
							</svg>
							<span class="mx-1">
								0823 8333 4000
							</span>
						</div>
					</a>
				</div>
			</div>
			<img class="obj-fit-cover obj-position-top position-absolute right bottom mb-n5 mr-5 d-none d-md-block" loading="lazy" width="275" height="300" src="<?= get_template_directory_uri() ?>/upload/woman.png">
		</div>
	</article>

	<article id="jobs" class="mt-md-4">
		<div class="container py-5 hover-card">
			<div class="pb-5">
				<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
					<div class="card-body">
						<div class="row">
							<div class="col-md-5 d-flex align-items-center">
								<div class="d-flex align-items-center justify-content-center rounded-circle font-title bg-theme-1 text-white mr-3">
									RFD
								</div>
								<h3 class="fs-4 text-break mb-0">
									React Frontend Developer
								</h3>
							</div>
							<div class="col-md-7">
								<hr class="my-3 d-md-none">
								<p class="opacity-5 text-break">
									Punya skill dan pengalaman membuat aplikasi dengan ReactJS? Yuk gabung bersama tim hebat kami!
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pb-5">
				<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
					<div class="card-body">
						<div class="row">
							<div class="col-md-5 d-flex align-items-center">
								<div class="d-flex align-items-center justify-content-center rounded-circle font-title bg-theme-1 text-white mr-3">
									CW
								</div>
								<h3 class="fs-4 text-break mb-0">
									Content Writer
								</h3>
							</div>
							<div class="col-md-7">
								<hr class="my-3 d-md-none">
								<p class="opacity-5 text-break">
									Hobi nulis soal bisnis dan keuangan? Kembangkan hobi dan bakatmu bersama GajiHub!
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pb-5">
				<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
					<div class="card-body">
						<div class="row">
							<div class="col-md-5 d-flex align-items-center">
								<div class="d-flex align-items-center justify-content-center rounded-circle font-title bg-theme-1 text-white mr-3">
									LBD
								</div>
								<h3 class="fs-4 text-break mb-0">
									Laravel PHP Backend Developer
								</h3>
							</div>
							<div class="col-md-7">
								<hr class="my-3 d-md-none">
								<p class="opacity-5 text-break">
									Jika kamu mengaku ninja di Laravel, kamu ga akan nyesel menjadi bagian penting dari tim GajiHub. Yuk!
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pb-5">
				<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
					<div class="card-body">
						<div class="row">
							<div class="col-md-5 d-flex align-items-center">
								<div class="d-flex align-items-center justify-content-center rounded-circle font-title bg-theme-1 text-white mr-3">
									GD
								</div>
								<h3 class="fs-4 text-break mb-0">
									Graphic Designer
								</h3>
							</div>
							<div class="col-md-7">
								<hr class="my-3 d-md-none">
								<p class="opacity-5 text-break">
									Punya pengalaman graphic design? GajiHub sangat membutuhkanmu. Yuk segera apply!
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pb-5">
				<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
					<div class="card-body">
						<div class="row">
							<div class="col-md-5 d-flex align-items-center">
								<div class="d-flex align-items-center justify-content-center rounded-circle font-title bg-theme-1 text-white mr-3">
									SS
								</div>
								<h3 class="fs-4 text-break mb-0">
									SEO Specialist
								</h3>
							</div>
							<div class="col-md-7">
								<hr class="my-3 d-md-none">
								<p class="opacity-5 text-break">
									Kalau kamu suka punya pengalaman dengan Search Engine Optimization, tim GajiHub sangat membutuhkan kemampuanmu. Langsung apply yuk!
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pb-5">
				<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
					<div class="card-body">
						<div class="row">
							<div class="col-md-5 d-flex align-items-center">
								<div class="d-flex align-items-center justify-content-center rounded-circle font-title bg-theme-1 text-white mr-3">
									SA
								</div>
								<h3 class="fs-4 text-break mb-0">
									Implementation Specialist – Accounting
								</h3>
							</div>
							<div class="col-md-7">
								<hr class="my-3 d-md-none">
								<p class="opacity-5 text-break">
									Bagi kamu yang lulusan jurusan Akuntansi, kembangkan karirmu untuk menjadi implementation specialist. Ga bakalan nyesel deh!
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="pb-5">
				<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
					<div class="card-body">
						<div class="row">
							<div class="col-md-5 d-flex align-items-center">
								<div class="d-flex align-items-center justify-content-center rounded-circle font-title bg-theme-1 text-white mr-3">
									SMM
								</div>
								<h3 class="fs-4 text-break mb-0">
									Social Media Manager
								</h3>
							</div>
							<div class="col-md-7">
								<hr class="my-3 d-md-none">
								<p class="opacity-5 text-break">
									Kamu terbiasa menggunakan social media termasuk Reels, Tik Tok, IG? Terbiasa membuat konten sekaligus menjadi talent? Yuk kembangka karier mu bersama GajiHub
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--theme-1-hover)" class="overlay-bottom">
			<polygon points="0,0 100,25 100,30 0,30"/>
		</svg>
		<style>
			#jobs .card .rounded-circle {
				width: 50px;
				height: 50px;
			}
			#jobs .card h3 {
				width: calc(100% - 50px - 1rem);
			}
		</style>
	</article>

<?php get_footer() ?>