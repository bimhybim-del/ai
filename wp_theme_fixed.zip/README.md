# GajiHub WP Theme

Tema Wordpress untuk gajihub

## Instalasi

1. Download sebagai zip
2. Upload ke WP Themes
3. Active kan tema
4. Ke menu Settings -> Theme Settings
5. Klik Install Dummy Page
