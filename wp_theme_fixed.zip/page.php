<?php get_header() ?>
<?php while(have_posts()): the_post(); ?>
    <article id="header" class="bg-theme-1 text-white pb-md-4 pb-lg-5 pt-lg-3">
		<div class="container pt-5 pb-5 pb-md-3">
			<h1 class="fs-1 text-break text-center mb-0">
				<?= get_the_title() ?>
			</h1>
		</div>
	</article>

	<article>
        <div class="container py-5">
			<div class="row">
				<div class="col-12">
		            <?php the_content() ?>
                </div>
            </div>
        </div>
	</article>

	<article>
		<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--theme-1-hover)" class="overlay-bottom">
			<polygon points="0,0 100,25 100,30 0,30"/>
		</svg>
	</article>
<?php endwhile ?>
<?php get_footer() ?>