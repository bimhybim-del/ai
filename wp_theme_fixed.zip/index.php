<?php $homepage = get_option('homepage_section'); ?>
<?php get_header() ?>

    <style>
        .carousel-multi .carousel-control-prev,
        .carousel-multi .carousel-control-next {
            filter: invert(1);
        }
        .carousel-multi .carousel-inner {
            overflow: initial;
        }
        .carousel-multi .carousel-item > div,
        .carousel-multi .carousel-control-prev,
        .carousel-multi .carousel-control-next {
            width: -moz-fit-content;
            width: fit-content;
        }
        .carousel-multi:not(:hover) .carousel-control-next-icon,
        .carousel-multi:not(:hover) .carousel-control-prev-icon {
            opacity: 1;
        }

        /*
            code by Iatek LLC 2018 - CC 2.0 License - Attribution required
            code customized by Azmind.com
        */
        @media (min-width: 768px) and (max-width: 991px) {
            .carousel-multi .carousel-inner .active.col-md-4.carousel-item + .carousel-item + .carousel-item + .carousel-item {
                position: absolute;
                top: 0;
                right: -33.3333%;
                z-index: -1;
                display: block;
                visibility: visible;
            }
        }
        @media (min-width: 576px) and (max-width: 768px) {
            .carousel-multi .carousel-inner .active.col-sm-6.carousel-item + .carousel-item + .carousel-item {
                position: absolute;
                top: 0;
                right: -50%;
                z-index: -1;
                display: block;
                visibility: visible;
            }
        }
        @media (min-width: 576px) {
            .carousel-multi .carousel-item {
                margin-right: 0;
            }
            .carousel-multi .carousel-inner .active + .carousel-item {
                display: block;
            }
            .carousel-multi .carousel-inner .carousel-item.active:not(.carousel-item-right):not(.carousel-item-left),
            .carousel-multi .carousel-inner .carousel-item.active:not(.carousel-item-right):not(.carousel-item-left) + .carousel-item {
                transition: none;
            }
            .carousel-multi .carousel-inner .carousel-item-next {
                position: relative;
                transform: translate3d(0, 0, 0);
            }
            .carousel-multi .active.carousel-item-left + .carousel-item-next.carousel-item-left,
            .carousel-multi .carousel-item-next.carousel-item-left + .carousel-item,
            .carousel-multi .carousel-item-next.carousel-item-left + .carousel-item + .carousel-item {
                position: relative;
                transform: translate3d(-100%, 0, 0);
                visibility: visible;
            }
            .carousel-multi .carousel-inner .carousel-item-prev.carousel-item-right {
                position: absolute;
                top: 0;
                left: 0;
                z-index: -1;
                display: block;
                visibility: visible;
            }
            .carousel-multi .active.carousel-item-right + .carousel-item-prev.carousel-item-right,
            .carousel-multi .carousel-item-prev.carousel-item-right + .carousel-item,
            .carousel-multi .carousel-item-prev.carousel-item-right + .carousel-item + .carousel-item {
                position: relative;
                transform: translate3d(100%, 0, 0);
                visibility: visible;
                display: block;
                visibility: visible;
            }
        }
        @media (min-width: 768px) {
            .carousel-multi .carousel-inner .active + .carousel-item + .carousel-item {
                display: block;
            }
            .carousel-multi .carousel-inner .carousel-item.active:not(.carousel-item-right):not(.carousel-item-left) + .carousel-item + .carousel-item {
                transition: none;
            }
            .carousel-multi .carousel-inner .carousel-item-next {
                position: relative;
                transform: translate3d(0, 0, 0);
            }
            .carousel-multi .carousel-item-next.carousel-item-left + .carousel-item + .carousel-item + .carousel-item {
                position: relative;
                transform: translate3d(-100%, 0, 0);
                visibility: visible;
            }
            .carousel-multi .carousel-item-prev.carousel-item-right + .carousel-item + .carousel-item + .carousel-item {
                position: relative;
                transform: translate3d(100%, 0, 0);
                visibility: visible;
                display: block;
                visibility: visible;
            }
        }
        @media (min-width: 991px) {
            .carousel-multi .carousel-inner .active + .carousel-item + .carousel-item + .carousel-item {
                display: block;
            }
            .carousel-multi .carousel-inner .carousel-item.active:not(.carousel-item-right):not(.carousel-item-left) + .carousel-item + .carousel-item + .carousel-item {
                transition: none;
            }
            .carousel-multi .carousel-inner .active.col-lg-3.carousel-item + .carousel-item + .carousel-item + .carousel-item + .carousel-item {
                position: absolute;
                top: 0;
                right: -25%;
                z-index: -1;
                display: block;
                visibility: visible;
            }
            .carousel-multi .carousel-item-next.carousel-item-left + .carousel-item + .carousel-item + .carousel-item + .carousel-item {
                position: relative;
                transform: translate3d(-100%, 0, 0);
                visibility: visible;
            }
            .carousel-multi .carousel-item-prev.carousel-item-right + .carousel-item + .carousel-item + .carousel-item + .carousel-item {
                position: relative;
                transform: translate3d(100%, 0, 0);
                visibility: visible;
                display: block;
                visibility: visible;
            }
        }
    </style>
    <article id="header" class="bg-theme-1 text-white pb-md-4 pb-lg-5 pt-lg-3">
		<div class="container py-5">
			<div class="row no-gutters align-items-lg-center">
				<div class="col-lg-6 order-lg-2 text-center">
					<img class="img-fluid px-5 mb-4 mb-lg-0" width="600" height="400" src="/wp-content/themes/gajihub/assets/img/gajihub-software-payroll.png" alt="GajiHub Software Payroll">
				</div>
				<div class="col-lg-6 order-lg-1 text-center text-lg-left">
					<h1 class="fs-1 text-break mb-3">
						<?= $homepage['homepage_hero_title'] ?>
					</h1>
					<p class="fs-6 text-break my-3 opacity-7">
						<?= $homepage['homepage_hero_tagline'] ?>
					</p>
					<div class="d-inline-block my-2 ml-lg-n2">
						<a class="btn btn-warning rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="<?= $homepage['homepage_hero_trial_url'] ?>">
							<div class="d-flex align-items-center">
								<span class="ml-1 mr-2">
									<?= $homepage['homepage_hero_trial_text'] ?>
								</span>
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
									<path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"/>
									<path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"/>
								</svg>
							</div>
						</a>
					</div>
					<!--
					<div class="d-inline-block my-2 ml-lg-n2 ml-xl-0">
						<button type="button" class="btn btn-outline-light rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" data-toggle="modal" data-target="#popupYoutube" data-embed="<?= $homepage['homepage_hero_demo_url'] ?>">
							<div class="d-flex align-items-center">
								<span class="ml-1 mr-2">
									<?= $homepage['homepage_hero_demo_text'] ?>
								</span>
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
									<path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"/>
									<path fill="#fff" d="M9.09961 12V10.52C9.09961 8.60999 10.4496 7.83999 12.0996 8.78999L13.3796 9.52999L14.6596 10.27C16.3096 11.22 16.3096 12.78 14.6596 13.73L13.3796 14.47L12.0996 15.21C10.4496 16.16 9.09961 15.38 9.09961 13.48V12Z"/>
								</svg>
							</div>
						</button>
					</div>
-->
				</div>
			</div>
		</div>
	</article>

	<article class="position-relative bg-light">
		<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--theme-1)" class="overlay-top overlay-flip-y">
			<polygon points="100,30 0,30 0,25 100,0"/>
		</svg>
		<div class="container py-5">
			<div class="row py-4">
				<div class="col-lg-6 order-lg-2 text-center">
					<img class="img-fluid mb-4" loading="lazy" width="600" height="400" src="<?= $homepage['homepage_featured_image'] ?>" alt="<?= $homepage['homepage_featured_title'] ?>">
				</div>
				<div class="col-lg-6 order-lg-1 text-center text-lg-left">
					<h2 class="fs-2 text-break mb-4">
						<?= $homepage['homepage_featured_title'] ?>
					</h2>
					<p class="fs-6 text-break opacity-5">
						<?= nl2br($homepage['homepage_featured_tagline']) ?>
					</p>
				</div>
			</div>
		</div>
		<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-bottom">
			<polygon points="0,0 100,25 100,30 0,30"/>
		</svg>
	</article>

	<article>
		<div class="container py-5">
			<div class="row mb-3">
				<div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
					<h2 class="fs-2 text-break mb-3 text-center">
						<?= $homepage['homepage_help_title'] ?>
					</h2>
				</div>
			</div>
			<div class="row text-center hover-card">
				<?php
                $args = array(
                    'post_type' => 'helps',
                    'post_status' => 'publish',
                    'posts_per_page' => -1
                );
                $helps = new WP_Query($args);
                if ($helps -> have_posts()) {
                    while ($helps -> have_posts()) {
                        $helps->the_post(); ?>
						<div class="col-md-6 col-lg-4 mx-auto mb-4 pb-md-3">
							<div class="card h-100 p-2 p-md-3 rounded-2 border-0 shadow hover-1">
								<div class="card-body">
									<img class="mb-3" loading="lazy" width="100" height="100" src="<?= get_the_post_thumbnail_url() ?>" alt="Icon">
									<h3 class="fs-4 text-break mb-3"><?php the_title() ?></h3>
									<p class="opacity-5 text-break"><?php the_content() ?></p>
								</div>
							</div>
						</div>
						<?php
                        // Or your video player code here
                    }
                }
                wp_reset_query();
                ?>
			</div>
		</div>
	</article>

    <article class="position-relative bg-theme-1">
        <svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-top">
            <polygon points="0,0 0,5 50,30 100,5 100,0"/>
        </svg>
        <div class="container pt-5 pb-3">
            <div class="row text-center">
                <div class="col-md-8 col-lg-7 col-xl-6 mx-auto">
                    <h2 class="fs-2 text-white mb-5">
                        Bagaimana Mobile Apps GajiHub Mentransofrmasi Perusahaan Anda?
                    </h2>
                </div>
            </div>
            <div id="carousel-client" class="carousel slide carousel-multi" data-ride="carousel" data-pause="true" data-interval="4000">
                <div class="carousel-inner row mx-auto">
                    <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3 active">
                        <a href="/absensi/">
                            <div class="bg-white text-center shadow rounded-2  mx-auto hover-1">
                                <img class="img-fluid d-block" loading="lazy" src="<?php echo get_parent_theme_file_uri() ?>/assets/img/apps/absensi.png" alt="Absensi">
                            </div>
                        </a>
                    </div>
                    <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                        <a href="/absensi/">
                            <div class="bg-white text-center shadow rounded-2  mx-auto hover-1">
                                <img class="img-fluid d-block" loading="lazy" src="<?php echo get_parent_theme_file_uri() ?>/assets/img/apps/client-visit.png" alt="Client Visit">
                            </div>
                        </a>
                    </div>
                    <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                        <a href="/cuti/">
                            <div class="bg-white text-center shadow rounded-2  mx-auto hover-1">
                                <img class="img-fluid d-block" loading="lazy" src="<?php echo get_parent_theme_file_uri() ?>/assets/img/apps/izin-cuti.png" alt="Izin Cuti">
                            </div>
                        </a>
                    </div>
                    <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                        <a href="/absensi/">
                            <div class="bg-white text-center shadow rounded-2  mx-auto hover-1">
                                <img class="img-fluid d-block" loading="lazy" src="<?php echo get_parent_theme_file_uri() ?>/assets/img/apps/jadwal.png" alt="Jadwal">
                            </div>
                        </a>
                    </div>
                    <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                        <a href="/analisis-data/">
                            <div class="bg-white text-center shadow rounded-2  mx-auto hover-1">
                                <img class="img-fluid d-block" loading="lazy" src="<?php echo get_parent_theme_file_uri() ?>/assets/img/apps/manajemen-karyawan.png" alt="Manajemen Karyawan">
                            </div>
                        </a>
                    </div>
                    <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                        <a href="/ess/">
                        <div class="bg-white text-center shadow rounded-2  mx-auto hover-1">
                            <img class="img-fluid d-block" loading="lazy" src="<?php echo get_parent_theme_file_uri() ?>/assets/img/apps/peraturan-perusahaan.png" alt="Peraturan Perusahaan">
                        </div>
                        </a>
                    </div>
                    <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                        <a href="/payroll/">
                        <div class="bg-white text-center shadow rounded-2  mx-auto hover-1">
                            <img class="img-fluid d-block" loading="lazy" src="<?php echo get_parent_theme_file_uri() ?>/assets/img/apps/slip-gaji.png" alt="Slip Gaji">
                        </div>
                        </a>
                    </div>
                    <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                        <a href="/ess/">
                            <div class="bg-white text-center shadow rounded-2  mx-auto hover-1">
                                <img class="img-fluid d-block" loading="lazy" src="<?php echo get_parent_theme_file_uri() ?>/assets/img/apps/sosial-media.png" alt="Sosial Media">
                            </div>
                        </a>
                    </div>
                </div>
                <a class="carousel-control-prev" style="margin-left:-20px" href="#carousel-client" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="false"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" style="margin-right:-20px" href="#carousel-client" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="false"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </article>

	<article class="parallax-overlay light mb-3">
		<section class="parallax py-4" data-parallax="<?= get_template_directory_uri() ?>/upload/banner-3.jpeg">

			<div class="container pt-5 pb-3">
				<div class="px-xl-5 mx-xl-3">
					<div class="d-flex justify-content-center font-title mb-5 pb-3 pricing-switch">
						<div class="d-flex bg-white rounded-pill shadow p-2">
							<button type="button" class="btn btn-clear fs-6 position-relative pointer-events-none" onclick="switchPrice('.pricing-switch','.pricing')">
								<span>per <b>Tahun</b></span>
								<div class="position-absolute top left right mt-n4">
									<span class="badge badge-success text-white rounded-pill p-2">10%</span>
								</div>
							</button>
							<div class="custom-control custom-switch custom-switch-lg switch-always-on switch-overlay ml-2" onclick="switchPrice('.pricing-switch','.pricing')">
								<input type="checkbox" class="custom-control-input" id="switchPricing">
								<label class="custom-control-label" for="switchPricing">
									<span class="sr-only">Switch Pricing</span>
								</label>
							</div>
							<button type="button" class="btn btn-clear fs-6" onclick="switchPrice('.pricing-switch','.pricing')">
								<span class="opacity-5">per <b>Bulan</b></span>
							</button>
						</div>
					</div>
					<div class="row no-gutters pricing">
					<?php
                    $args = array(
                        'post_type' => 'prices',
                        'post_status' => 'publish',
                        'posts_per_page' => -1
                    );
                    $prices = new WP_Query($args);
                    if ($prices -> have_posts()) {
                        $n = 0;
                        while ($prices -> have_posts()) {
                            $n++;
                            $add_classes = [
                                '',
                                'mt-md-4 pt-md-2',
                                'index-1',
                                'mt-md-4 pt-md-2'
                            ];
                            $add_classes_2 = [
                                '',
                                'rounded-right-md-0 index-1',
                                'index-2',
                                'rounded-left-md-0 index-1'
                            ];
                            $id = get_the_ID();
                            $prices->the_post();
                            $yearly_value = get_post_meta($id, '_price_yearly', true);
                            $monthly_value = get_post_meta($id, '_price_monthly', true);
							$detectMonthlyValue = (int)str_replace('.', '', $monthly_value);//jadikan integer
                            $items_value = get_post_meta($id, '_price_items', true);
                            $class_text = get_post_meta($id, '_class_text', true); ?>
					<div class="col-md-4 mb-4 pb-2 <?=$add_classes[$n]?>">
						<div class="card bg-white border-0 rounded-3 <?=$add_classes_2[$n]?> shadow text-center text-break">
							<div class="card-body py-4 px-lg-4">
								<h3 class="fs-5 lh-2 text-uppercase font-title font-weight-bold my-2">
									<?php the_title() ?>
								</h3>
								<div class="font-title mt-3 mb-4">
									<div class="fs-1 d-flex align-items-center justify-content-center text-<?=$class_text?> lh-2 mr-4 mr-lg-0 mr-xl-4 pr-2 pr-md-3">
										<span class="fs-4 opacity-2 text-dark mb-1 mr-1">Rp</span>
										<b><?= $yearly_value ?></b>
										<b class="d-none"><?= $monthly_value ?></b>
									</div>
									<div class="opacity-3"><?php the_content() ?></div>
								</div>
								<div class="separator my-3 mx-auto w-75"></div>
								<ul class="list-group list-group-flush lh-2 mb-0">
									<?php foreach ($items_value as $item): ?>
									<li class="list-group-item bg-transparent border-0 py-2 px-0"><?=$item?></li>
									<?php endforeach ?>
									<li class="list-group-item bg-transparent border-0 py-2 px-0 d-none d-md-block">&nbsp;</li>
								</ul>
								<?php
                                if ($detectMonthlyValue <= 14000) {
                                    ?>
									<?php
										if($id != 33 && $id != 34){
									?>
										<!-- Untuk Free -->
										<a class="btn btn-warning rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="<?= $homepage['homepage_hero_trial_url'] ?>?requests[]=<?=get_the_ID()?>">
											<div class="d-flex align-items-center">
												<span class="ml-1 mr-2">
													Daftar
												</span>
												<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
													<path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path>
													<path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"></path>
												</svg>
											</div>
										</a>
										<!-- End Untuk Free-->
									<?php }else if($id == 34){ ?>
										<!--<strong>Coming Soon!</strong>-->
										<!-- Untuk Pro -->
											<a class="btn btn-danger rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="<?= $homepage['homepage_hero_trial_url'] ?>?requests[]=<?=get_the_ID()?>">
											<div class="d-flex align-items-center">
												<span class="ml-1 mr-2">
													Daftar
												</span>
												<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
													<path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path>
													<path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"></path>
												</svg>
											</div>
										</a>
										<!-- -->
									<?php }elseif($id == 33){ ?>
										<!-- Untuk Elite -->
											<a class="btn btn-info rounded-pill py-2 pl-4 fs-7 text-uppercase ws-nowrap mx-2" href="<?= $homepage['homepage_hero_trial_url'] ?>?requests[]=<?=get_the_ID()?>">
											<div class="d-flex align-items-center">
												<span class="ml-1 mr-2">
													Daftar
												</span>
												<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40">
													<path fill="#292D32" opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"></path>
													<path fill="#fff" d="M16.03 11.4699L13.03 8.46994C12.74 8.17994 12.26 8.17994 11.97 8.46994C11.68 8.75994 11.68 9.23994 11.97 9.52994L13.69 11.2499H8.5C8.09 11.2499 7.75 11.5899 7.75 11.9999C7.75 12.4099 8.09 12.7499 8.5 12.7499H13.69L11.97 14.4699C11.68 14.7599 11.68 15.2399 11.97 15.5299C12.12 15.6799 12.31 15.7499 12.5 15.7499C12.69 15.7499 12.88 15.6799 13.03 15.5299L16.03 12.5299C16.32 12.2399 16.32 11.7599 16.03 11.4699Z"></path>
												</svg>
											</div>
										</a>
										<!-- Elite -->

								<?php
									}
								}
								?>

							</div>
							<div class="card-footer bg-<?=$class_text?> w-25 border-0 rounded-3 py-1 mt-2 mb-4 mx-auto"></div>
						</div>
					</div>
					<?php
                                // Or your video player code here
                        }
                    }
                    wp_reset_query();
                    ?>
				</div>
				</div>
			</div>
			<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-bottom mb-n4">
				<polygon points="100,30 0,30 0,0 50,25 100,0"/>
			</svg>
		</section>
	</article>

	<article>
		<div class="container pt-5 pb-3">
			<div class="row text-center">
				<div class="col-md-8 col-lg-7 col-xl-6 mx-auto">
					<h2 class="fs-2 text-break mb-5">
						<?= $homepage['homepage_testimonial_title'] ?>
					</h2>
				</div>
			</div>
			<div class="row">
			<?php
                $args = array(
                    'post_type' => 'testimonials',
                    'post_status' => 'publish',
                    'posts_per_page' => -1
                );
                $testimonials = new WP_Query($args);
                if ($testimonials -> have_posts()) {
                    while ($testimonials -> have_posts()) {
                        $testimonials->the_post();
                        $video_url = get_post_meta(get_the_ID(), '_testimonial_video_url', true); ?>
				<div class="col-md-4 mb-4 pb-2 mt-md-4 pt-md-3">
					<div class="card bg-white border-0 rounded-3 shadow text-center text-break hover-1">
						<div class="card-header position-relative border-0 p-0 cursor-pointer" data-toggle="modal" data-target="#popupYoutube" data-embed="<?= $video_url ?>">
							<div class="position-absolute w-100 h-100 d-flex align-items-center justify-content-center">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40" fill="#fff">
									<path opacity=".25" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"/>
									<path d="M9.09961 12V10.52C9.09961 8.60999 10.4496 7.83999 12.0996 8.78999L13.3796 9.52999L14.6596 10.27C16.3096 11.22 16.3096 12.78 14.6596 13.73L13.3796 14.47L12.0996 15.21C10.4496 16.16 9.09961 15.38 9.09961 13.48V12Z"/>
								</svg>
							</div>
							<img class="obj-fit-cover rounded-3 rounded-bottom-0" loading="lazy" width="600" height="400" src="<?= get_the_post_thumbnail_url() ?>" alt="<?php the_title() ?>">
						</div>
						<div class="card-body py-4 px-lg-4">
							<p class="opacity-7">
								<?php the_content() ?>
							</p>
							<span class="d-inline-block small bg-theme-1 text-white rounded-2 py-2 px-3">
							<?php the_title() ?>
							</span>
						</div>
					</div>
				</div>
				<?php
                        // Or your video player code here
                    }
                }
                wp_reset_query();
                ?>
			</div>
		</div>
	</article>

    <article class="position-relative bg-theme-1">
        <svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-top">
            <polygon points="0,0 0,5 50,30 100,5 100,0"/>
        </svg>
        <section class="overflow-hidden text-white">
            <div class="container py-5">
                <div class="row mb-3 text-center">
                    <div class="col-md-8 col-lg-7 col-xl-6 mx-auto">
                        <h2 class="fs-2 text-break mb-3">
                            Telah Diliput Oleh
                        </h2>
                    </div>
                </div>
                <div class="mb-3">
                    <div id="carousel-client-2" class="carousel slide carousel-multi" data-ride="carousel" data-pause="false" data-interval="4000">
                        <div class="carousel-inner row w-100 mx-auto">
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3 active">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/kontan.png" alt="Kontan">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/wartaekonomi.png" alt="Warta Ekonomi">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/infokomputer.png" alt="InfoKomputer">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/investing.png" alt="Investing">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/tribun.png" alt="Tribun">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/tempoco.png" alt="Tempo">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/tagar.png" alt="Tagar">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/itech.png" alt="iTech">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/kedaulatan-rakyat.png" alt="Kedaulatan Rakyat">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/siar.png" alt="SIAR">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/kabarbisnis.png" alt="Kabar Bisnis">
                                </div>
                            </div>
                            <div class="carousel-item col-12 col-sm-6 col-md-4 col-lg-3">
                                <div class="bg-white text-center shadow rounded-2 py-3 px-4 mx-auto hover-1">
                                    <img class="img-fluid d-block" loading="lazy" width="128" height="37" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/media/linenews.png" alt="Line News">
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carousel-client-2" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carousel-client-2" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>

                </div>
            </div>
        </section>
        <svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--theme-1-hover)" class="overlay-bottom">
            <polygon points="0,0 100,25 100,30 0,30"/>
        </svg>
    </article>
	<article id="popupModal">
		<script>
			document.addEventListener('DOMContentLoaded', function() {
				popupYoutube('#popupModal','#popupYoutube',800,450)
			})
		</script>
	</article>


<?php get_footer() ?>