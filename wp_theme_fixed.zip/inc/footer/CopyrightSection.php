<?php

class CopyrightSection
{
    private static $prefix = "footer_copyright_";
    private static $options;
    private static $sections = [
        'copyright' => [
            'label' => 'Copyright Text',
            'callback' => 'copyright_text_callback',
        ],
        'term' => [
            'label' => 'Term',
            'callback' => 'term_callback',
        ],
        'term_url' => [
            'label' => 'Term URL',
            'callback' => 'term_url_callback',
        ],
        'privacy' => [
            'label' => 'Privacy',
            'callback' => 'privacy_callback',
        ],
        'privacy_url' => [
            'label' => 'Privacy URL',
            'callback' => 'privacy_url_callback',
        ],
    ];

    public static function init($options)
    {
        self::$options = $options;
        add_settings_section( self::$prefix.'section', 'Footer Copyright Settings', array(CopyrightSection::class,'section_callback'), 'theme_options' );
        foreach(self::$sections as $name => $value)
        {
            add_settings_field( self::$prefix.$name, $value['label'], array(CopyrightSection::class,$value['callback']), 'theme_options', self::$prefix.'section' );
        }
    }

    public function copyright_text_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."copyright]' placeholder='Text Here...' type='text' value='".self::$options[self::$prefix.'copyright']."' />";
    }

    public function term_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."term]' placeholder='Text Here...' type='text' value='".self::$options[self::$prefix.'term']."' />";
    }
    
    public function term_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."term_url]' placeholder='URL Here...' type='text' value='".self::$options[self::$prefix.'term_url']."' />";
    }

    public function privacy_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."privacy]' placeholder='Text Here...' type='text' value='".self::$options[self::$prefix.'privacy']."' />";
    }
    
    public function privacy_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."privacy_url]' placeholder='URL Here...' type='text' value='".self::$options[self::$prefix.'privacy_url']."' />";
    }

    public function section_callback()
    {

    }
}