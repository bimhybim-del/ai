<?php

class FirstSection
{
    private static $prefix = "footer_first_";
    private static $options;
    private static $sections = [
        'phone' => [
            'label' => 'Phone',
            'callback' => 'phone_callback',
        ],
        'phone_url' => [
            'label' => 'Phone URL',
            'callback' => 'phone_url_callback',
        ],
        'email' => [
            'label' => 'Email',
            'callback' => 'email_callback',
        ],
        'address' => [
            'label' => 'Address',
            'callback' => 'address_callback',
        ],
        'facebook_url' => [
            'label' => 'Facebook URL',
            'callback' => 'facebook_url_callback',
        ],
        'twitter_url' => [
            'label' => 'Twitter URL',
            'callback' => 'twitter_url_callback',
        ],
        'instagram_url' => [
            'label' => 'Instagram URL',
            'callback' => 'instagram_url_callback',
        ],
        'youtube_url' => [
            'label' => 'YouTube URL',
            'callback' => 'youtube_url_callback',
        ],
        'linkedin_url' => [
            'label' => 'Linkedin URL',
            'callback' => 'linkedin_url_callback',
        ],
        'playstore_url' => [
            'label' => 'Playstore URL',
            'callback' => 'playstore_url_callback',
        ],
        'appstore_url' => [
            'label' => 'AppStore URL',
            'callback' => 'appstore_url_callback',
        ],
    ];

    public static function init($options)
    {
        self::$options = $options;
        add_settings_section( self::$prefix.'section', 'Footer Settings', array(FirstSection::class,'section_callback'), 'theme_options' );
        foreach(self::$sections as $name => $value)
        {
            add_settings_field( self::$prefix.$name, $value['label'], array(FirstSection::class,$value['callback']), 'theme_options', self::$prefix.'section' );
        }
    }

    public function phone_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."phone]' placeholder='Phone Here...' type='text' value='".self::$options[self::$prefix.'phone']."' />";
    }

    public function phone_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."phone_url]' placeholder='Phone URL Here...' type='text' value='".self::$options[self::$prefix.'phone_url']."' />";
    }
    public function email_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."email]' placeholder='Email Here...' type='email' value='".self::$options[self::$prefix.'email']."' />";
    }

    public function address_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."address]' placeholder='Address Here...' type='text' value='".self::$options[self::$prefix.'address']."' />";
    }

    public function facebook_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."facebook_url]' placeholder='Facebook URL Here...' type='text' value='".self::$options[self::$prefix.'facebook_url']."' />";
    }

    public function twitter_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."twitter_url]' placeholder='Twitter URL Here...' type='text' value='".self::$options[self::$prefix.'twitter_url']."' />";
    }

    public function instagram_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."instagram_url]' placeholder='Instagram URL Here...' type='text' value='".self::$options[self::$prefix.'instagram_url']."' />";
    }

    public function youtube_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."youtube_url]' placeholder='YouTube URL Here...' type='text' value='".self::$options[self::$prefix.'youtube_url']."' />";
    }

    public function linkedin_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."linkedin_url]' placeholder='LinkedIn URL Here...' type='text' value='".self::$options[self::$prefix.'linkedin_url']."' />";
    }

    public function playstore_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."playstore_url]' placeholder='Playstore URL Here...' type='text' value='".self::$options[self::$prefix.'playstore_url']."' />";
    }

    public function appstore_url_callback(){
        echo "<input class='gh_theme_setting_form_style' name='footer_section[".self::$prefix."appstore_url]' placeholder='AppStore URL Here...' type='text' value='".self::$options[self::$prefix.'appstore_url']."' />";
    }

    public function section_callback()
    {

    }
}