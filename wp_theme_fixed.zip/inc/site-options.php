<?php

class Theme_Options
{
    public $options;

    public function __construct()
    {
        $this->options  = get_option('gh_theme_settings');
        $this->homepage = get_option('homepage_section');
        $this->footer   = get_option('footer_section');
        $this->register_settings_and_fields();
    }

    public static function add_menu_page()
    {
        add_options_page('GajiHub Theme Settings ', 'Theme Settings', 'administrator', 'theme_settings', array('Theme_Options','display_option_page'));
    }

    public static function get_section()
    {
        return isset($_GET['section']) ? $_GET['section'] : 'homepage';
    }

    public static function display_option_page()
    {
        $section = self::get_section();
        $nav_active = [
            'homepage' => '',
            'footer'   => '',
            'default'  => ''
        ];
        $nav_active[$section] = 'nav-tab-active'; ?>
        <div class="wrap">
            <h2>GajiHub Theme Settings</h2>
            <h2 class="nav-tab-wrapper">
                <a href="options-general.php?page=theme_settings&section=homepage" class="nav-tab <?=$nav_active['homepage']?>">Homepage Setting</a>
                <a href="options-general.php?page=theme_settings&section=footer" class="nav-tab <?=$nav_active['footer']?>">Footer Setting</a>
                <a href="options-general.php?page=theme_settings&section=default" class="nav-tab <?=$nav_active['default']?>">Default Data</a>
            </h2>

            <?php if ($section != 'default'): ?>
            <form action="options.php" method="post" enctype="multipart/form-data">
                <?php
                settings_fields($section.'_section');
        do_settings_sections('theme_options'); ?>
                <p class="submit">
                  <input name="submit" type="submit" class="button-primary" value="Save changes"/>
                  <button type="button" class="button-primary" onclick="fillDefault('<?=$section?>')">Fill Default Value</button>
                </p>
            </form>

            <?php else: ?>
            <h2>GajiHub Default Theme Data</h2>
            <form action="options.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="install_dummy_page" value="true">
                <?php
                settings_fields('default_theme_data');
        do_settings_sections('theme_data'); ?>
                <p>Click Install Theme Data button to install default theme data</p>
                <p class="submit">
                  <input name="submit" type="submit" class="button-primary" value="Install Theme Data"/>
                </p>
            </form>
            <?php endif ?>
        </div>
        <script>
        function fillDefault(section)
        {
            var defaultValues = {
                homepage : {
                    hero_title:"Sudahi Kerepotan Pengelolaan HR dan Payroll Bisnis Anda",
                    hero_tagline:"Dengan GajiHub, Anda bisa mengelola proses Payroll dan HR dalam satu software terintegrasi. Hitung gaji, pajak, dan pengelolaan data karyawan jadi lebih praktis.",
                    hero_trial_text:"Daftar <b>Gratis Selamanya</b>",
                    hero_trial_url:"<?=get_site_url()?>",
                    hero_demo_text:"Lihat <b>Video Demo</b>",
                    hero_demo_url:"https://www.youtube.com/embed/1bEDPfhZKOA",
                    featured_title:"Semua proses manajemen SDM kini dalam satu sistem",
                    featured_tagline:"Dengan satu platform untuk data karyawan, HR, dan operasional, semua orang dapat mengakses data secara real time untuk membuat keputusan yang tepat. Anda dapat mengandalkan software HR dan payroll GajiHub untuk menghadirkan teknologi yang mendorong pertumbuhan bisnis dan menjaga keamanan data Anda.",
                    help_title:"Bagaimana Software HR dan Payroll GajiHub Membantu Anda?",
                    testimonial_title:"Mereka Yang Sudah Menggunakan GajiHub",
                    cover_title:"Telah Diliput Oleh",
                    hero_image_url_field:"<?= get_template_directory_uri()?>/upload/slider-1.png",
                    featured_image_url_field:"<?= get_template_directory_uri()?>/upload/hero-2.png",
                },
                footer: {
                    copyright_copyright:'&copy; 2021 <a class="text-decoration-none text-white" href="index.html">GajiHub</a> <span class="opacity-8">by PT Kledo Berhati Nyaman. Developed with </span>',
                    copyright_term:'Syarat & Ketentuan',
                    copyright_term_url:'<?=get_site_url()?>/term',
                    copyright_privacy:'Kebijakan Privasi',
                    copyright_privacy_url:'<?=get_site_url()?>/privacy',
                    first_phone:'+62 81 222 8000 70',
                    first_phone_url:'https://wa.me/6281222800070',
                    first_email:'hello@gajihub.com',
                    first_address:'Jl. Kledokan No B10, Catur Tunggal, Depok, DIY, 55281',
                    first_facebook_url:'https://www.facebook.com/',
                    first_twitter_url:'https://twitter.com/',
                    first_instagram_url:'https://instagram.com/',
                    first_youtube_url:'https://youtube.com/',
                    first_linkedin_url:'https://linkedin.com/',
                    first_playstore_url:'https://play.google.com/',
                    first_appstore_url:'https://google.com/',
                }
            }

            var fill_section = defaultValues[section]
            for(_section in fill_section)
            {
                var selector = "[name='"+section+"_section["+section+"_"+_section+"]']"
                console.log(selector)
                var el = document.querySelector(selector)
                el.value = fill_section[_section]
            }
        }
        </script>

        <?php
    }

    public function register_settings_and_fields()
    {
        register_setting('gh_theme_settings', 'gh_theme_settings', array($this,'gh_validate_settings'));
        
        register_setting('homepage_section', 'homepage_section', array($this,'homepage_section_validate_settings'));
        
        register_setting('footer_section', 'footer_section', array($this,'footer_section_validate_settings'));
        
        register_setting('default_theme_data', 'default_theme_data', array($this,'validate_settings'));

        $section = self::get_section();

        if ($section == 'homepage') {
            MetaSection::init($this->homepage);
            
            HeroSection::init($this->homepage);
            
            FeaturedSection::init($this->homepage);
            
            HelpSection::init($this->homepage);
            
            TestimonialSection::init($this->homepage);
            
            CoverSection::init($this->homepage);
        }
        
        if ($section == 'footer') {
            FirstSection::init($this->footer);
            
            CopyrightSection::init($this->footer);
        }

        
        // add_settings_field( 'author_avatar', 'Your Image', array($this,'author_avatar_call_back'), 'theme_option', 'author_section' );
        
        // add_settings_field( 'author_facebook_url', 'Your Facebook Profile', array($this,'author_facebook_url_call_back'), 'theme_option', 'author_section' );
    }

    public function author_avatar_call_back()
    {
        echo '<input type="file" name="author_avatar_upload" /> <br/> <br/>';
        if (isset($this->options['author_avatar'])) {
            echo "<img src='{$this->options['author_avatar']}' style='height:100px; width:100px;'>";
        }
    }
    
    public function author_facebook_url_call_back()
    {
        echo "<input name='author_box[author_facebook_url]' type='text' value='{$this->options['author_facebook_url']}' />";
    }

    public function validate_settings($data)
    {
        // if(!empty($_FILES['author_avatar_upload']['tmp_name'])){
        //     $override = array('test_form' => false);
        //     $file = wp_handle_upload($_FILES['author_avatar_upload'],$override);
        //     $author_box['author_avatar'] = $file['url'];
        // }else{
        //     $author_box['author_avatar'] = $this->options['author_avatar'];
        // }
        return $data;
    }

    public function gh_validate_settings($gh_data)
    {
        // if(!empty($_FILES['featured_image_upload']['tmp_name'])){
        //     $override = array('test_form' => false);
        //     $file = wp_handle_upload($_FILES['featured_image_upload'],$override);
        //     $gh_data['homepage_featured_image'] = $file['url'];
        // }else{
        //     $gh_data['homepage_featured_image'] = $this->options['homepage_featured_image'];
        // }
        return $gh_data;
    }

    public function homepage_section_validate_settings($data)
    {
        if (!empty($_FILES['hero_image_upload']['name'])) {
            $override = array('test_form' => false);
            $file = wp_handle_upload($_FILES['hero_image_upload'], $override);
            $data['homepage_hero_image'] = $file['url'];
        } else {
            $data['homepage_hero_image'] = $this->homepage['homepage_hero_image'];
            if (isset($_POST['delete']) && $_POST['delete'] == 'hero_image') {
                $data['homepage_hero_image'] = "";
            }

            if (isset($_POST['homepage_section']['homepage_hero_image_url_field']) && $_POST['homepage_section']['homepage_hero_image_url_field']) {
                $data['homepage_hero_image'] = $_POST['homepage_section']['homepage_hero_image_url_field'];
            }
        }

        if (!empty($_FILES['featured_image_upload']['name'])) {
            $override = array('test_form' => false);
            $file = wp_handle_upload($_FILES['featured_image_upload'], $override);
            $data['homepage_featured_image'] = $file['url'];
        } else {
            $data['homepage_featured_image'] = $this->homepage['homepage_featured_image'];
            if (isset($_POST['delete']) && $_POST['delete'] == 'featured_image') {
                $data['homepage_featured_image'] = "";
            }
            
            if (isset($_POST['homepage_section']['homepage_featured_image_url_field']) && $_POST['homepage_section']['homepage_featured_image_url_field']) {
                $data['homepage_featured_image'] = $_POST['homepage_section']['homepage_featured_image_url_field'];
            }
        }
        return $data;
    }

    public function footer_section_validate_settings($data)
    {
        return $data;
    }
}


add_action('admin_menu', function () {
    Theme_Options::add_menu_page();
});

add_action('admin_init', function () {
    new Theme_Options();
});
