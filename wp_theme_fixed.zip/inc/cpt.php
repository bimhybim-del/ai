<?php

// Our custom post type function
function create_helps_posttype() {
 
    register_post_type( 'helps',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Helps' ),
                'singular_name' => __( 'Help' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'helps'),
            'show_in_rest' => true,
            'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' )
 
        )
    );
}

// Our custom post type function
function create_prices_posttype() {
 
    register_post_type( 'prices',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Prices' ),
                'singular_name' => __( 'Price' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'prices'),
            'show_in_rest' => true,
            'supports' => array( 'title', 'editor' )
        )
    );
}

// Our custom post type function
function create_testimonials_posttype() {
 
    register_post_type( 'testimonials',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Testimonials' ),
                'singular_name' => __( 'Testimonial' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'testimonials'),
            'show_in_rest' => true,
            'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' )
        )
    );
}

// Our custom post type function
function create_covers_posttype() {
 
    register_post_type( 'covers',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Covers' ),
                'singular_name' => __( 'Cover' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'covers'),
            'show_in_rest' => true,
            'supports' => array( 'title', 'thumbnail' )
        )
    );
}

// Our custom post type function
function create_tutorials_posttype() {
 
    register_post_type( 'tutorials',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Tutorials' ),
                'singular_name' => __( 'Tutorial' )
            ),
            'taxonomies' => array( 'tutorial_categories' ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'tutorials'),
            'show_in_rest' => true,
            'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' )
        )
    );
}

// Our custom post type function
function create_videos_posttype() {
 
    register_post_type( 'videos',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Videos' ),
                'singular_name' => __( 'Video' )
            ),
            'taxonomies' => array( 'video_categories' ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'videos'),
            'show_in_rest' => true,
            'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' )
        )
    );
}

function tutorial_taxonomy() {
    register_taxonomy(
        'tutorial_categories',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
        'tutorials',            // post type name
        array(
            'hierarchical' => true,
            'label' => __('Categories'), // display name
            'query_var' => true,
            'show_in_rest' => true,
            'show_admin_column' => true,
            'rewrite' => array(
                'slug' => 'tutorial-categories',    // This controls the base slug that will display before each term
                'with_front' => false      // Don't display the category base before
            )
        )
    );
}

function video_taxonomy() {
    register_taxonomy(
        'video_categories',  // The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
        'videos',            // post type name
        array(
            'hierarchical' => true,
            'label' => __('Categories'), // display name
            'query_var' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'rewrite' => array(
                'slug' => 'video-categories',    // This controls the base slug that will display before each term
                'with_front' => false      // Don't display the category base before
            )
        )
    );
}

add_action( 'init', 'tutorial_taxonomy');
add_action( 'init', 'video_taxonomy');

// Hooking up our function to theme setup
add_action( 'init', 'create_helps_posttype' );
add_action( 'init', 'create_prices_posttype' );
add_action( 'init', 'create_testimonials_posttype' );
add_action( 'init', 'create_covers_posttype' );
add_action( 'init', 'create_tutorials_posttype' );
add_action( 'init', 'create_videos_posttype' );
