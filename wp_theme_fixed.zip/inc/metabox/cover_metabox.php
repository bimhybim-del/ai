<?php

function cover_cpt_add_meta_box() {
    //this will add the metabox for the member post type
    $screens = array( 'covers' );
    
    foreach ( $screens as $screen ) {
    
        add_meta_box(
            'cover_metabox',
            __( 'Cover Additional Field', 'cover_textdomain' ),
            'cover_metabox_callback',
            $screen
        );
    }
}
add_action( 'add_meta_boxes', 'cover_cpt_add_meta_box' );
    
/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function cover_metabox_callback( $post ) {
    
    // Add a nonce field so we can check for it later.
    wp_nonce_field( 'cover_save_meta_box_data', 'cover_meta_box_nonce' );
    
    /*
     * Use get_post_meta() to retrieve an existing value
     * from the database and use the value for the form.
     */
    $value = get_post_meta( $post->ID, '_cover_url', true );
    
    echo '<p><label for="cover_url">';
    _e( 'Cover URL', 'cover_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="url" id="cover_url" name="cover_url" value="' . esc_attr( $value ) . '"/></p>';
}
    
/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function cover_save_meta_box_data( $post_id ) {
    
     if ( ! isset( $_POST['cover_meta_box_nonce'] ) ) {
        return;
     }
    
     if ( ! wp_verify_nonce( $_POST['cover_meta_box_nonce'], 'cover_save_meta_box_data' ) ) {
        return;
     }
    
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    
    // Check the user's permissions.
    if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
    
        if ( ! current_user_can( 'edit_page', $post_id ) ) {
            return;
        }
    
    } else {
    
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    }
    
    if ( ! isset( $_POST['cover_url'] ) ) {
        return;
    }
    
    $my_data = sanitize_text_field( $_POST['cover_url'] );
    
    update_post_meta( $post_id, '_cover_url', $my_data );
}
add_action( 'save_post', 'cover_save_meta_box_data' );