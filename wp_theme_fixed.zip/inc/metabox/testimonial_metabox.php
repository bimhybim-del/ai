<?php

function testimonial_cpt_add_meta_box() {
    //this will add the metabox for the member post type
    $screens = array( 'testimonials' );
    
    foreach ( $screens as $screen ) {
    
        add_meta_box(
            'testimonial_metabox',
            __( 'Testimonial Additional Field', 'testimonial_textdomain' ),
            'testimonial_metabox_callback',
            $screen
        );
    }
}
add_action( 'add_meta_boxes', 'testimonial_cpt_add_meta_box' );
    
/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function testimonial_metabox_callback( $post ) {
    
    // Add a nonce field so we can check for it later.
    wp_nonce_field( 'testimonial_save_meta_box_data', 'testimonial_meta_box_nonce' );
    
    /*
     * Use get_post_meta() to retrieve an existing value
     * from the database and use the value for the form.
     */
    $value = get_post_meta( $post->ID, '_testimonial_video_url', true );
    
    echo '<p><label for="testimonial_video_url">';
    _e( 'Video URL', 'testimonial_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="url" id="testimonial_video_url" name="testimonial_video_url" value="' . esc_attr( $value ) . '"/></p>';
}
    
/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function testimonial_save_meta_box_data( $post_id ) {
    
     if ( ! isset( $_POST['testimonial_meta_box_nonce'] ) ) {
        return;
     }
    
     if ( ! wp_verify_nonce( $_POST['testimonial_meta_box_nonce'], 'testimonial_save_meta_box_data' ) ) {
        return;
     }
    
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    
    // Check the user's permissions.
    if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
    
        if ( ! current_user_can( 'edit_page', $post_id ) ) {
            return;
        }
    
    } else {
    
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    }
    
    if ( ! isset( $_POST['testimonial_video_url'] ) ) {
        return;
    }
    
    $my_data = sanitize_text_field( $_POST['testimonial_video_url'] );
    
    update_post_meta( $post_id, '_testimonial_video_url', $my_data );
}
add_action( 'save_post', 'testimonial_save_meta_box_data' );