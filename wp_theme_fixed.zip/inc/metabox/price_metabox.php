<?php

function price_cpt_add_meta_box() {
    //this will add the metabox for the member post type
    $screens = array( 'prices' );
    
    foreach ( $screens as $screen ) {
    
        add_meta_box(
            'price_metabox',
            __( 'Price Additional Field', 'price_textdomain' ),
            'price_metabox_callback',
            $screen
        );
    }
}
add_action( 'add_meta_boxes', 'price_cpt_add_meta_box' );
    
/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function price_metabox_callback( $post ) {
    
    // Add a nonce field so we can check for it later.
    wp_nonce_field( 'price_save_meta_box_data', 'price_meta_box_nonce' );
    
    /*
     * Use get_post_meta() to retrieve an existing value
     * from the database and use the value for the form.
     */
    $yearly_value = get_post_meta( $post->ID, '_price_yearly', true );
    $monthly_value = get_post_meta( $post->ID, '_price_monthly', true );
    $items_value = get_post_meta( $post->ID, '_price_items', true );
    $items_value = !empty($items_value) ? $items_value : [];
    $class_text = get_post_meta( $post->ID, '_class_text', true );

    $items_element = "";
    foreach($items_value as $item)
    {
        $items_element .= '<p style="display:flex;">
        <button type="button" onclick="deleteItem(this)">X</button>
        <input class="gh_theme_setting_form_style" type="text" name="price_items[]" value="'.$item.'"/>
        </p>';
    }

    echo '<p><label for="class_text">';
    _e( 'Class Color (warning, primary, secondary)', 'price_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="text" id="class_text" name="class_text" value="' . esc_attr( $class_text ) . '"/></p>';
    
    echo '<p><label for="price_yearly">';
    _e( 'Harga Tahunan', 'price_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="number" id="price_yearly" name="price_yearly" value="' . esc_attr( $yearly_value ) . '"/></p>';

    echo '<p><label for="price_monthly">';
    _e( 'Harga Bulanan', 'price_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="number" id="price_monthly" name="price_monthly" value="' . esc_attr( $monthly_value ) . '"/></p>';

    echo '<p><label>Items</label><br>';
    echo '<button class="" type="button" onclick="appendItem()">Add Item</button>';
    echo '</p>';

    echo '<div id="list-items">'.$items_element.'</div>';
}
    
/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function price_save_meta_box_data( $post_id ) {
    
     if ( ! isset( $_POST['price_meta_box_nonce'] ) ) {
        return;
     }
    
     if ( ! wp_verify_nonce( $_POST['price_meta_box_nonce'], 'price_save_meta_box_data' ) ) {
        return;
     }
    
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    
    // Check the user's permissions.
    if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
    
        if ( ! current_user_can( 'edit_page', $post_id ) ) {
            return;
        }
    
    } else {
    
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    }
    
    if ( 
        ! isset( $_POST['price_yearly'] ) &&
        ! isset( $_POST['price_monthly'] ) &&
        ! isset( $_POST['class_text'] ) &&
        ! isset( $_POST['price_items'] )
    ) {
        return;
    }
    
    $class_text = sanitize_text_field( $_POST['class_text'] );
    $yearly_value = sanitize_text_field( $_POST['price_yearly'] );
    $monthly_value = sanitize_text_field( $_POST['price_monthly'] );
    $items_value = $_POST['price_items'];
    
    update_post_meta( $post_id, '_class_text', $class_text );
    update_post_meta( $post_id, '_price_yearly', $yearly_value );
    update_post_meta( $post_id, '_price_monthly', $monthly_value );
    update_post_meta( $post_id, '_price_items', $items_value );
}
add_action( 'save_post', 'price_save_meta_box_data' );