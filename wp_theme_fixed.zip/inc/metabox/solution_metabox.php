<?php

function solution_add_meta_box() {
    global $post;

    if(!empty($post))
    {
        $pageTemplate = get_post_meta($post->ID, '_wp_page_template', true);

        if($pageTemplate == 'template/solution-template.php' )
        {
            add_meta_box(
                'solution_metabox',
                __( 'Solution Additional Field', 'solution_textdomain' ),
                'solution_metabox_callback',
                'page'
            );
        }
    }
}
add_action( 'add_meta_boxes', 'solution_add_meta_box' );
    
/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function solution_metabox_callback( $post ) {
    
    // Add a nonce field so we can check for it later.
    wp_nonce_field( 'solution_save_meta_box_data', 'solution_meta_box_nonce' );
    
    /*
     * Use get_post_meta() to retrieve an existing value
     * from the database and use the value for the form.
     */
    $tagline = get_post_meta( $post->ID, '_tagline', true );
    $button_text = get_post_meta( $post->ID, '_button_text', true );
    $button_url = get_post_meta( $post->ID, '_button_url', true );
    
    echo '<p><label for="tagline">';
    _e( 'Tagline', 'solution_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="text" id="tagline" name="tagline" value="' . esc_attr( $tagline ) . '"/></p>';

    echo '<p><label for="button_text">';
    _e( 'Button Text', 'solution_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="text" id="button_text" name="button_text" value="' . esc_attr( $button_text ) . '"/></p>';

    echo '<p><label for="button_url">';
    _e( 'Button URL', 'solution_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="text" id="button_url" name="button_url" value="' . esc_attr( $button_url ) . '"/></p>';
}
    
/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function solution_save_meta_box_data( $post_id ) {
    
     if ( ! isset( $_POST['solution_meta_box_nonce'] ) ) {
        return;
     }
    
     if ( ! wp_verify_nonce( $_POST['solution_meta_box_nonce'], 'solution_save_meta_box_data' ) ) {
        return;
     }
    
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    
    // Check the user's permissions.
    if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
    
        if ( ! current_user_can( 'edit_page', $post_id ) ) {
            return;
        }
    
    } else {
    
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    }
    
    if ( 
        ! isset( $_POST['tagline'] ) &&
        ! isset( $_POST['button_text'] ) &&
        ! isset( $_POST['button_url'] )
    ) {
        return;
    }
    
    $tagline = sanitize_text_field( $_POST['tagline'] );
    $button_text = sanitize_text_field( $_POST['button_text'] );
    $button_url = sanitize_text_field( $_POST['button_url'] );
    
    update_post_meta( $post_id, '_tagline', $tagline );
    update_post_meta( $post_id, '_button_text', $button_text );
    update_post_meta( $post_id, '_button_url', $button_url );
}
add_action( 'save_post', 'solution_save_meta_box_data' );