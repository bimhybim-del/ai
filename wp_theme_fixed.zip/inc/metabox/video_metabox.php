<?php

function video_cpt_add_meta_box() {
    //this will add the metabox for the member post type
    $screens = array( 'videos' );
    
    foreach ( $screens as $screen ) {
    
        add_meta_box(
            'video_metabox',
            __( 'Video Additional Field', 'video_textdomain' ),
            'video_metabox_callback',
            $screen
        );
    }
}
add_action( 'add_meta_boxes', 'video_cpt_add_meta_box' );
    
/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function video_metabox_callback( $post ) {
    
    // Add a nonce field so we can check for it later.
    wp_nonce_field( 'video_save_meta_box_data', 'video_meta_box_nonce' );
    
    /*
     * Use get_post_meta() to retrieve an existing value
     * from the database and use the value for the form.
     */
    $youtube_playlist_value = get_post_meta( $post->ID, '_video_youtube_playlist', true );
    $youtube_id_value = get_post_meta( $post->ID, '_video_youtube_id', true );
    $youtube_duration_value = get_post_meta( $post->ID, '_video_youtube_duration', true );
    $youtube_thumbnail_value = get_post_meta( $post->ID, '_video_youtube_thumbnail', true );
    
    echo '<p><label for="youtube_playlist">';
    _e( 'Youtube Playlist', 'video_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="text" id="youtube_playlist" name="youtube_playlist" value="' . esc_attr( $youtube_playlist_value ) . '"/></p>';

    echo '<p><label for="youtube_id">';
    _e( 'Youtube ID', 'video_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="text" id="youtube_id" name="youtube_id" value="' . esc_attr( $youtube_id_value ) . '"/></p>';

    echo '<p><label for="youtube_duration">';
    _e( 'Youtube Duration', 'video_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="text" id="youtube_duration" name="youtube_duration" value="' . esc_attr( $youtube_duration_value ) . '"/></p>';

    echo '<p><label for="youtube_thumbnail">';
    _e( 'Youtube Thumbnail', 'video_textdomain' );
    echo '</label><br>';
    echo '<input class="gh_theme_setting_form_style" type="text" id="youtube_thumbnail" name="youtube_thumbnail" value="' . esc_attr( $youtube_thumbnail_value ) . '"/></p>';

}
    
/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function video_save_meta_box_data( $post_id ) {
    
     if ( ! isset( $_POST['video_meta_box_nonce'] ) ) {
        return;
     }
    
     if ( ! wp_verify_nonce( $_POST['video_meta_box_nonce'], 'video_save_meta_box_data' ) ) {
        return;
     }
    
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    
    // Check the user's permissions.
    if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
    
        if ( ! current_user_can( 'edit_page', $post_id ) ) {
            return;
        }
    
    } else {
    
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    }
    
    if ( 
        ! isset( $_POST['youtube_playlist'] ) &&
        ! isset( $_POST['youtube_id'] ) &&
        ! isset( $_POST['youtube_duration'] ) &&
        ! isset( $_POST['youtube_thumbnail'] )
    ) {
        return;
    }
    
    $youtube_playlist = sanitize_text_field( $_POST['youtube_playlist'] );
    $youtube_id = sanitize_text_field( $_POST['youtube_id'] );
    $youtube_duration = sanitize_text_field( $_POST['youtube_duration'] );
    $youtube_thumbnail = sanitize_text_field( $_POST['youtube_thumbnail'] );
    
    update_post_meta( $post_id, '_video_youtube_playlist', $youtube_playlist );
    update_post_meta( $post_id, '_video_youtube_id', $youtube_id );
    update_post_meta( $post_id, '_video_youtube_duration', $youtube_duration );
    update_post_meta( $post_id, '_video_youtube_thumbnail', $youtube_thumbnail );
}
add_action( 'save_post', 'video_save_meta_box_data' );