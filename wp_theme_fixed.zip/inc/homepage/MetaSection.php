<?php

class MetaSection
{
    private static $prefix = "homepage_meta_";
    private static $options;
    private static $sections = [
        'additional' => [
            'label' => 'Additional Meta',
            'callback' => 'additional_callback',
        ],
    ];

    public static function init($options)
    {
        self::$options = $options;
        add_settings_section( self::$prefix.'section', 'Homepage Meta', array(MetaSection::class,'section_callback'), 'theme_options' );
        foreach(self::$sections as $name => $value)
        {
            add_settings_field( self::$prefix.$name, $value['label'], array(MetaSection::class,$value['callback']), 'theme_options', self::$prefix.'section' );
        }
    }

    public function additional_callback(){
        echo "<textarea class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."additional]' placeholder='Meta Here...'>".self::$options[self::$prefix.'additional']."</textarea>";
    }

    public function section_callback()
    {

    }
}