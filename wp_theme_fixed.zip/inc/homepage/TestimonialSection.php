<?php

class TestimonialSection
{
    private static $prefix = "homepage_testimonial_";
    private static $options;
    private static $sections = [
        'title' => [
            'label' => 'Testimonial Title',
            'callback' => 'title_callback',
        ],
    ];

    public static function init($options)
    {
        self::$options = $options;
        add_settings_section( self::$prefix.'section', 'Homepage Testimonial Settings', array(TestimonialSection::class,'section_callback'), 'theme_options' );
        foreach(self::$sections as $name => $value)
        {
            add_settings_field( self::$prefix.$name, $value['label'], array(TestimonialSection::class,$value['callback']), 'theme_options', self::$prefix.'section' );
        }
    }

    public function title_callback(){
        echo "<input class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."title]' placeholder='Title Here...' type='text' value='".self::$options[self::$prefix.'title']."' />";
    }

    public function section_callback()
    {

    }
}