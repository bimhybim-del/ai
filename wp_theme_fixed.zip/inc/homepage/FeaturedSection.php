<?php

class FeaturedSection
{
    private static $prefix = 'homepage_featured_';
    private static $options;
    private static $sections = [
        'title' => [
            'label' => 'Featured Title',
            'callback' => 'title_callback',
        ],
        'tagline' => [
            'label' => 'Featured Tagline',
            'callback' => 'tagline_callback',
        ],
        'image' => [
            'label' => 'Featured Image',
            'callback' => 'image_callback',
        ],

    ];

    public static function init($options)
    {
        self::$options = $options;
        add_settings_section( self::$prefix.'section', 'Homepage Featured Settings', array(FeaturedSection::class,'section_callback'), 'theme_options' );
        foreach(self::$sections as $name => $value)
        {
            add_settings_field( $name, $value['label'], array(FeaturedSection::class,$value['callback']), 'theme_options', self::$prefix.'section' );
        }
    }

    public function title_callback(){
        echo "<input class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."title]' placeholder='Title Here...' type='text' value='".self::$options[self::$prefix.'title']."' />";
    }
    
    public function tagline_callback()
    {
        echo "<textarea class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."tagline]' placeholder='Tagline Here...'>".self::$options[self::$prefix.'tagline']."</textarea>";
    }

    public function image_callback(){
        echo '<input type="hidden" name="homepage_section[homepage_featured_image_url_field]" />';
        echo '<input class="gh_theme_setting_form_style" type="file" name="featured_image_upload" /> <br/> <br/>';
        if(isset(self::$options[self::$prefix.'image']) && self::$options[self::$prefix.'image']){
            echo "<img src='".self::$options[self::$prefix.'image']."' style='height:auto; width:250px;'>";
            echo "<br><button type='submit' name='delete' value='featured_image'>Delete</button>";
        }
    }

    public function section_callback(){

    }

}