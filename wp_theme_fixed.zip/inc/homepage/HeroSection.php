<?php

class HeroSection
{
    private static $prefix = 'homepage_hero_';
    private static $options;
    private static $sections = [
        'title' => [
            'label' => 'Hero Title',
            'callback' => 'title_callback',
        ],
        'tagline' => [
            'label' => 'Hero Tagline',
            'callback' => 'tagline_callback',
        ],
        'image' => [
            'label' => 'Hero Image',
            'callback' => 'image_callback',
        ],
        'trial_text' => [
            'label' => 'Hero Trial Text',
            'callback' => 'trial_text_callback',
        ],
        'trial_url' => [
            'label' => 'Hero Trial URL',
            'callback' => 'trial_url_callback',
        ],
        'demo_text' => [
            'label' => 'Hero Demo Text',
            'callback' => 'demo_text_callback',
        ],
        'demo_url' => [
            'label' => 'Hero Demo URL',
            'callback' => 'demo_url_callback',
        ],

    ];

    public static function init($options)
    {
        self::$options = $options;
        add_settings_section( self::$prefix.'section', 'Homepage Hero Settings', array(HeroSection::class,'section_callback'), 'theme_options' );
        foreach(self::$sections as $name => $value)
        {
            add_settings_field( self::$prefix.$name, $value['label'], array(HeroSection::class,$value['callback']), 'theme_options', self::$prefix.'section' );
        }
    }

    public function title_callback(){
        echo "<input class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."title]' placeholder='Title Here...' type='text' value='".self::$options[self::$prefix.'title']."' />";
    }
    
    public function tagline_callback()
    {
        echo "<input class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."tagline]' placeholder='Tagline Here...' type='text' value='".self::$options[self::$prefix.'tagline']."' />";
    }
    
    public function trial_text_callback()
    {
        echo "<input class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."trial_text]' placeholder='Text Here...' type='text' value='".self::$options[self::$prefix.'trial_text']."' />";
    }
    
    public function trial_url_callback()
    {
        echo "<input class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."trial_url]' placeholder='URL Here...' type='text' value='".self::$options[self::$prefix.'trial_url']."' />";
    }
    
    public function demo_text_callback()
    {
        echo "<input class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."demo_text]' placeholder='Text Here...' type='text' value='".self::$options[self::$prefix.'demo_text']."' />";
    }
    
    public function demo_url_callback()
    {
        echo "<input class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."demo_url]' placeholder='URL Here...' type='url' value='".self::$options[self::$prefix.'demo_url']."' />";
    }

    public function image_callback(){
        echo '<input type="hidden" name="homepage_section[homepage_hero_image_url_field]" />';
        echo '<input class="gh_theme_setting_form_style" type="file" name="hero_image_upload" /> <br/> <br/>';
        if(isset(self::$options[self::$prefix.'image']) && self::$options[self::$prefix.'image']){
            echo "<img src='".self::$options[self::$prefix.'image']."' style='height:auto; width:250px;'>";
            echo "<br><button type='submit' name='delete' value='hero_image'>Delete</button>";
        }
    }

    public function section_callback(){

    }

}