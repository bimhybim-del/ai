<?php

class HelpSection
{
    private static $prefix = "homepage_help_";
    private static $options;
    private static $sections = [
        'title' => [
            'label' => 'Help Title',
            'callback' => 'title_callback',
        ],
    ];

    public static function init($options)
    {
        self::$options = $options;
        add_settings_section( self::$prefix.'section', 'Homepage Help Settings', array(HelpSection::class,'section_callback'), 'theme_options' );
        foreach(self::$sections as $name => $value)
        {
            add_settings_field( self::$prefix.$name, $value['label'], array(HelpSection::class,$value['callback']), 'theme_options', self::$prefix.'section' );
        }
    }

    public function title_callback(){
        echo "<input class='gh_theme_setting_form_style' name='homepage_section[".self::$prefix."title]' placeholder='Title Here...' type='text' value='".self::$options[self::$prefix.'title']."' />";
    }

    public function section_callback()
    {

    }
}