<?php

function mytheme_setup()
{

    //  if(get_option('page_on_front')=='0' && get_option('show_on_front')=='posts'){
    $pages = [
        'Tentang'        => ['template/about-template.php','tentang'],
        'Karir'          => ['template/career-template.php','karir'],
        'Demo'           => ['template/demo-template.php','demo'],
        'Fitur'          => ['template/feature-template.php','feature'],
        'Harga'          => ['template/price-template.php','harga'],
        'Privasi'        => ['template/privacy-template.php','privacy'],
        'Proposal'       => ['template/proposal-template.php','proposal'],
        'Term'           => ['template/term-template.php','term'],
        'Tutorial'       => ['template/tutorial-template.php','tutorial'],
        'Tutorial Video' => ['template/tutorial-video-template.php','video'],
        'Referal'        => ['template/referal-template.php','referal'],
    ];

    foreach ($pages as $page => $template) {
        // Create homepage
        $_page = array(
            'post_type'     => 'page',
            'post_name'     => $template[1],
            'post_title'    => $page,
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1
        );
        // Insert the post into the database
        $_page_id =  wp_insert_post($_page);
        //set the page template
        //assuming you have defined template on your-template-filename.php
        update_post_meta($_page_id, '_wp_page_template', $template[0]);
    }
    // }
}

function solution_menu_setup()
{

    //  if(get_option('page_on_front')=='0' && get_option('show_on_front')=='posts'){
    $pages = [
        'Payroll'                   => ['template/solution-template.php','payroll satu dua'],
        'Absensi'                   => ['template/solution-template.php','absensi'],
        'HRIS'                      => ['template/solution-template.php','hris'],
        'Kelola PPh 21'             => ['template/solution-template.php','kelola-pph-21'],
        'BPJS'                      => ['template/solution-template.php','bpjs'],
        'Akuntansi'                 => ['template/solution-template.php','akuntansi'],
        'Reimbursement'             => ['template/solution-template.php','reimbursement'],
        'ESS Employee Self Service' => ['template/solution-template.php','ess'],
        'Kelola Aset'               => ['template/solution-template.php','kelola-aset'],
        'Kelola Cuti & Izin'        => ['template/solution-template.php','kelola-cuti-izin'],
        'Analisa Data'              => ['template/solution-template.php','analisa-data'],
    ];

    $content = require 'solution-content.php';

    foreach ($pages as $page => $template) {
        $post = get_page_by_title($page);
        wp_delete_post($post->ID, true);
        // Create homepage
        $_page = array(
            'post_type'     => 'page',
            'post_name'     => $template[1],
            'post_title'    => $page,
            'post_content'  => $content,
            'post_status'   => 'publish',
            'post_author'   => 1
        );
        // Insert the post into the database
        $_page_id =  wp_insert_post($_page);
        //set the page template
        //assuming you have defined template on your-template-filename.php
        update_post_meta($_page_id, '_wp_page_template', $template[0]);
        update_post_meta($_page_id, '_tagline', 'Tagline Disini');
        update_post_meta($_page_id, '_button_text', 'Text Tombol Disini');
        update_post_meta($_page_id, '_button_url', get_site_url());
    }
    // }
}

function prices_setup()
{

    //  if(get_option('page_on_front')=='0' && get_option('show_on_front')=='posts'){
    $pages = [
        [
            'title'   => 'Pro',
            'content' => 'per bulan',
            'meta'    => [
                '_class_text' => 'info',
                '_price_yearly' => 4750,
                '_price_monthly' => 5000,
                '_price_items' => [
                    '---',
                    '---',
                    '---',
                ],
            ]
        ],
        [
            'title'   => 'Elit',
            'content' => 'per bulan',
            'meta'    => [
                '_class_text' => 'theme-1',
                '_price_yearly' => 5700,
                '_price_monthly' => 6000,
                '_price_items' => [
                    '---',
                    '---',
                    '---',
                    '---',
                    '---',
                    '---',
                ],
            ]
        ],
        [
            'title'   => 'Gratis',
            'content' => 'per bulan',
            'meta'    => [
                '_class_text' => 'warning',
                '_price_yearly' => 0,
                '_price_monthly' => 0,
                '_price_items' => [
                    '---',
                    '---',
                    '---',
                ],
            ]
        ],
    ];

    foreach ($pages as $page => $template) {
        // Create homepage
        $_page = array(
            'post_type'     => 'prices',
            'post_name'     => $template['title'],
            'post_title'    => $template['title'],
            'post_content'  => $template['content'],
            'post_status'   => 'publish',
            'post_author'   => 1
        );
        // Insert the post into the database
        $_page_id =  wp_insert_post($_page);
        //set the page template
        //assuming you have defined template on your-template-filename.php
        foreach ($template['meta'] as $key => $value) {
            update_post_meta($_page_id, $key, $value);
        }
    }
    // }
}

function helps_setup()
{
    $helps = [
        [
            'title' => 'Kelola data karyawan lebih mudah',
            'content' => 'Seluruh data karyawan bisa Anda akses dan kelola dalam satu sistem sehingga memudahkan Anda dalam melakukan manajemen SDM lebih efisien.',
            'icon'  => 'upload/icon-1.png',
        ],
        [
            'title' => 'Mencatat absensi karyawan',
            'content' => 'Informasi dan pencatatan absensi berjalan lebih optimal dengan dengan integrasi langsung ke sistem penggajian perusahan.',
            'icon'  => 'upload/icon-2.png',
        ],
        [
            'title' => 'Mengelola pola kerja',
            'content' => 'Perusahaan Anda menerapkan peraturan jam kerja yang beragam atau memiliki pembagian pola kerja? Dengan GajiHub membuat pengelolaan jam kerja menjadi lebih mudah!',
            'icon'  => 'upload/icon-3.png',
        ],
        [
            'title' => 'Pengelolaan cuti dan izin karyawan',
            'content' => 'Anda mengelola izin karyawan yang berlaku di perusahaan Anda dengan mudah. Di GajiHub Anda juga fleksibel mengakomodasi periode cuti individu dan periode bersama.',
            'icon'  => 'upload/icon-4.png',
        ],
        [
            'title' => 'Analisis kinerja karyawan',
            'content' => 'GajiHub menyediakan fitur yang Anda butuhkan untuk Analisis Kinerja Karyawan secara real-time di satu tempat. Mulai dari Data Kompensasi, Demografi Karyawan, sampai Data Produktivitas bisa Anda peroleh di GajiHub.',
            'icon'  => 'upload/icon-5.png',
        ],
        [
            'title' => 'Menghitung gaji, THR, dan benefit Lainnya',
            'content' => 'Sistem penggajian karyawan di GajiHub fleksibel dan dapat diakses online memudahkan perhitungan gaji karyawan dengan beragam komponen tunjangan, termasuk mengkalkulasi lembur, THR, bonus dan benefit lainnya.',
            'icon'  => 'upload/icon-6.png',
        ],
        [
            'title' => 'Penghitungan pajak karyawan dan BPJS',
            'content' => 'Mulai dari penghitungan PPh 21 dan PPh 26, kini Anda bisa melakukan itu semua dengan praktis di GajiHub. Anda juga dapat menghitung premi BPJS, baik BPJS Ketenagakerjaan maupun BPJS langsung dari sistem GajiHub.',
            'icon'  => 'upload/icon-7.png',
        ],
        [
            'title' => 'Multi approval',
            'content' => 'Pengajuan cuti karyawan membutuhkan persetujuan lebih dari satu orang atau beberapa level yang berbeda? Di GajiHub, proses ini dapat dikelola dengan mudah sesuai struktur organisasi yang berlaku di perusahaan.',
            'icon'  => 'upload/icon-8.png',
        ],
        [
            'title' => 'Struktur dan skala upah',
            'content' => 'Dengan GajiHub, Anda bisa mengatur struktur dan skala upah. Dengan adanya fitur ini, Anda bisa merancang struktur golongan jabatan beserta range pendapatan berdasarkan golongan tersebut.',
            'icon'  => 'upload/icon-9.png',
        ],
    ];

    foreach ($helps as $help) {
        // Create homepage
        $_post = array(
            'post_type'     => 'helps',
            'post_name'     => $help['title'],
            'post_title'    => $help['title'],
            'post_content'  => $help['content'],
            'post_status'   => 'publish',
            'post_author'   => 1
        );
        // Insert the post into the database
        $_post_id =  wp_insert_post($_post);
        $filename = explode('/', $help['icon'])[1];
        $file     = get_template_directory_uri().'/'.$help['icon'];
        $upload_file = wp_upload_bits($filename, null, @file_get_contents($file));
        if (!$upload_file['error']) {
            //if succesfull insert the new file into the media library (create a new attachment post type)
            $wp_filetype = wp_check_filetype($filename, null);
            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_parent' => $_post_id,
                'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                'post_content' => '',
                'post_status' => 'inherit'
            );
            //wp_insert_attachment( $attachment, $filename, $parent_post_id );
            $attachment_id = wp_insert_attachment($attachment, $upload_file['file'], $_post_id);
            if (!is_wp_error($attachment_id)) {
                //if attachment post was successfully created, insert it as a thumbnail to the post $post_id
                require_once(ABSPATH . "wp-admin" . '/includes/image.php');
                //wp_generate_attachment_metadata( $attachment_id, $file ); for images
                $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload_file['file']);
                wp_update_attachment_metadata($attachment_id, $attachment_data);
                set_post_thumbnail($_post_id, $attachment_id);
            }
        }
    }
}

function testimonials_setup()
{
    $testimonials = [
        [
            'title' => 'Ferry, Co Founder Kerjoo',
            'content' => 'Mengurus pajak dan bpjs karyawan itu sungguh membingungkan. Tapi dengan GajiHub, kita tau beres deh, semua sudah dihitungkan oleh GajiHub',
            'icon'  => 'upload/kerjoo.jpeg',
            'video_url' => 'https://www.youtube.com/embed/n8MYkAllSVA',
        ],
        [
            'title' => 'Adi, Founder Niffly Jewelry',
            'content' => 'Karyawan pada suka menggunakan GajiHub, karena mau reimburs atau klaim lembur jadi ga repot lagi.',
            'icon'  => 'upload/niffly.jpeg',
            'video_url' => 'https://www.youtube.com/embed/09i9VKDpx8w'
        ],
        [
            'title' => 'Ana, Owner Batiklurik.id',
            'content' => 'Mengurus payroll di akhir bulan bisa sangat melelahkan. Tapi semenjak make GajiHub, cuman perlu klik klik aja langsung beres!',
            'icon'  => 'upload/batiklurik.jpeg',
            'video_url' => 'https://www.youtube.com/embed/8q6oy5wRTrA'
        ],
    ];

    foreach ($testimonials as $testimonial) {
        // Create homepage
        $_post = array(
            'post_type'     => 'testimonials',
            'post_name'     => $testimonial['title'],
            'post_title'    => $testimonial['title'],
            'post_content'  => $testimonial['content'],
            'post_status'   => 'publish',
            'post_author'   => 1
        );
        // Insert the post into the database
        $_post_id =  wp_insert_post($_post);
        update_post_meta($_post_id, '_testimonial_video_url', $testimonial['video_url']);
        $filename = explode('/', $testimonial['icon'])[1];
        $file     = get_template_directory_uri().'/'.$testimonial['icon'];
        $upload_file = wp_upload_bits($filename, null, @file_get_contents($file));
        if (!$upload_file['error']) {
            //if succesfull insert the new file into the media library (create a new attachment post type)
            $wp_filetype = wp_check_filetype($filename, null);
            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_parent' => $_post_id,
                'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                'post_content' => '',
                'post_status' => 'inherit'
            );
            //wp_insert_attachment( $attachment, $filename, $parent_post_id );
            $attachment_id = wp_insert_attachment($attachment, $upload_file['file'], $_post_id);
            if (!is_wp_error($attachment_id)) {
                //if attachment post was successfully created, insert it as a thumbnail to the post $post_id
                require_once(ABSPATH . "wp-admin" . '/includes/image.php');
                //wp_generate_attachment_metadata( $attachment_id, $file ); for images
                $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload_file['file']);
                wp_update_attachment_metadata($attachment_id, $attachment_data);
                set_post_thumbnail($_post_id, $attachment_id);
            }
        }
    }
}

function covers_setup()
{
    $covers = [
        'upload/infokomputer.png',
        'upload/investing.png',
        'upload/itech.png',
        'upload/tempoco.png',
    ];

    foreach ($covers as $key => $cover) {
        // Create homepage
        $_post = array(
            'post_type'     => 'covers',
            'post_name'     => 'cover-'.$key,
            'post_title'    => 'cover-'.$key,
            'post_content'  => 'cover-'.$key,
            'post_status'   => 'publish',
            'post_author'   => 1
        );
        // Insert the post into the database
        $_post_id =  wp_insert_post($_post);
        $filename = explode('/', $cover)[1];
        $file     = get_template_directory_uri().'/'.$cover;
        $upload_file = wp_upload_bits($filename, null, @file_get_contents($file));
        if (!$upload_file['error']) {
            //if succesfull insert the new file into the media library (create a new attachment post type)
            $wp_filetype = wp_check_filetype($filename, null);
            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_parent' => $_post_id,
                'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                'post_content' => '',
                'post_status' => 'inherit'
            );
            //wp_insert_attachment( $attachment, $filename, $parent_post_id );
            $attachment_id = wp_insert_attachment($attachment, $upload_file['file'], $_post_id);
            if (!is_wp_error($attachment_id)) {
                //if attachment post was successfully created, insert it as a thumbnail to the post $post_id
                require_once(ABSPATH . "wp-admin" . '/includes/image.php');
                //wp_generate_attachment_metadata( $attachment_id, $file ); for images
                $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload_file['file']);
                wp_update_attachment_metadata($attachment_id, $attachment_data);
                set_post_thumbnail($_post_id, $attachment_id);
            }
        }
    }
}

function setup_menu($menu_id, $menu, $m)
{
    $menus = [
        'Header Menu' => [
            [
                'title' => 'Harga',
                'url'   => home_url('/price'),
            ],
            [
                'title' => 'Tentang',
                'url'   => home_url('/about'),
            ],
            [
                'title' => 'Fitur',
                'url'   => '#',
                'child' => [
                    [
                        'title' => 'Invoice',
                        'url'   => home_url('/about'),
                    ],
                    [
                        'title' => 'Purchasing',
                        'url'   => home_url('/about'),
                    ],
                    [
                        'title' => 'Biaya',
                        'url'   => home_url('/about'),
                    ],
                    [
                        'title' => 'Laporan',
                        'url'   => home_url('/about'),
                    ],
                    [
                        'title' => 'Aset Tetap',
                        'url'   => home_url('/about'),
                    ],
                    [
                        'title' => 'Inventori',
                        'url'   => home_url('/about'),
                    ],
                ]
            ],
        ],
        'About Footer Menu' => [
            [
                'title' => 'Tentang',
                'url'   => home_url('/about'),
            ],
            [
                'title' => 'Blog',
                'url'   => home_url('/blog'),
            ],
            [
                'title' => 'Karir',
                'url'   => home_url('/career'),
            ],
            [
                'title' => 'Tutorial',
                'url'   => home_url('/tutorial'),
            ],
            [
                'title' => 'Video Tutorial',
                'url'   => home_url('/video'),
            ],
            [
                'title' => 'Keamanan',
                'url'   => home_url('/keamanan'),
            ],
            [
                'title' => 'Jadwalkan Demo',
                'url'   => home_url('/demo'),
            ],
            [
                'title' => 'Download Proposal',
                'url'   => home_url('/proposal'),
            ],
            [
                'title' => 'Login',
                'url'   => home_url('/login'),
            ],
        ],
        'Service Footer Menu' => [
            [
                'title' => 'Perbandingan Harga',
                'url'   => home_url('/price'),
            ],
            [
                'title' => 'Invoice',
                'url'   => '#',
            ],
            [
                'title' => 'Purchasing',
                'url'   => '#',
            ],
            [
                'title' => 'Pencatatan Biaya',
                'url'   => '#',
            ],
            [
                'title' => 'Laporan Keuangan',
                'url'   => '#',
            ],
            [
                'title' => 'Aset Tetap',
                'url'   => '#',
            ],
            [
                'title' => 'Inventori',
                'url'   => '#',
            ],
            [
                'title' => 'Referal',
                'url'   => '#',
            ],
            [
                'title' => 'Integrasi',
                'url'   => '#',
            ],
        ],
        'Tool Footer Menu' => [
            [
                'title' => 'Software Gratis',
                'url'   => '#',
            ],
            [
                'title' => 'Buat Invoice',
                'url'   => '#',
            ],
            [
                'title' => 'Contoh Surat Bisnis',
                'url'   => '#',
            ]
        ]
    ];

    // Set up default menu items
    foreach ($menus[$menu] as $_menu) {
        $item_id = wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-title'   =>  __($_menu['title'], 'textdomain'),
            'menu-item-classes' => strtolower($_menu['title']),
            'menu-item-url'     => $_menu['url'],
            'menu-item-status'  => 'publish'
        ));

        if (isset($_menu['child'])) {
            foreach ($_menu['child'] as $child) {
                wp_update_nav_menu_item($menu_id, 0, array(
                    'menu-item-title'   =>  __($child['title'], 'textdomain'),
                    'menu-item-classes' => strtolower($child['title']),
                    'menu-item-url'     => $child['url'],
                    'menu-item-status'  => 'publish',
                    'menu-item-parent-id' => $item_id
                ));
            }
        }
    }

    $locations = get_theme_mod('nav_menu_locations');
    $locations[$m] = $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
}

function init_theme_setup()
{
    if (get_page_by_title('Tentang') == null) {
        mytheme_setup();
    }

    if (get_page_by_title('Kelola data karyawan lebih mudah', OBJECT, 'helps') == null) {
        helps_setup();
    }

    if (get_page_by_title('Pro', OBJECT, 'prices') == null) {
        prices_setup();
    }

    if (get_page_by_title('Author - Jobs', OBJECT, 'testimonials') == null) {
        testimonials_setup();
    }

    if (get_page_by_title('cover-1', OBJECT, 'covers') == null) {
        covers_setup();
    }
    // do_settings_sections(__FILE__);

    // Check if the menu exists
    $menus = [
        'Header Menu' => 'header-menu',
        'About Footer Menu' => 'footer-menu-1',
        'Service Footer Menu' => 'footer-menu-2',
        'Tool Footer Menu' => 'footer-menu-3',
    ];
    foreach ($menus as $menu => $m) {
        $menu_exists = wp_get_nav_menu_object($menu);
        if (! $menu_exists) {
            $menu_id = wp_create_nav_menu($menu);
    
            setup_menu($menu_id, $menu, $m);
        }
    }
}

function init_header_submenu()
{
    $menu_exists = wp_get_nav_menu_items('Header Menu');
    if ($menu_exists) {
        $menu = wp_get_nav_menu_object('Header Menu');
        $is_taxs = [];
        foreach ($menu_exists as $menu_item) {
            if ($menu_item->type != 'taxonomy') {
                $is_taxs[] = $menu_item;
            }
        }
    }
}

if (! is_admin()) {
    // init_header_submenu();
}

add_filter('wp_nav_menu_items', 'custom_menu_item', 10, 2);
function custom_menu_item($menu, $args)
{
    if ($args->menu == 'top') {
        $item = '<li class="nav-item d-md-inline-block mx-md-2 dropdown">';
        $item .= '<a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Solusi
                    </a>';
        $item .= '<ul class="dropdown-menu rounded-2">';
        $args = array(
            'meta_key' => '_wp_page_template',
            'meta_value' => 'template/solution-template.php',
            'sort_column' => 'ID'
        );
        /*
        diganti hardcode aja
        $pages = get_pages($args);
        foreach($pages as $page)
        {
            $item .= '<li><a class="dropdown-item ws-init" href="'.get_permalink($page->ID).'">'.$page->post_title.'</a></li>';';
        }
        */
        $item .= '<li><a class="dropdown-item ws-init" href="/payroll/">Payroll</a></li>';
        $item .= '<li><a class="dropdown-item ws-init" href="/absensi/">Absensi</a></li>';
        // $item .= '<li><a class="dropdown-item ws-init" href="/hris/">HRIS</a></li>';
        $item .= '<li><a class="dropdown-item ws-init" href="/kelola-pph-21/">Kelola PPh 21</a></li>';
        $item .= '<li><a class="dropdown-item ws-init" href="/bpjs/">BPJS</a></li>';
        $item .= '<li><a class="dropdown-item ws-init" href="/akuntansi/">Akuntansi</a></li>';
        // $item .= '<li><a class="dropdown-item ws-init" href="/reimbursement/">Reimbursement</a></li>';
        $item .= '<li><a class="dropdown-item ws-init" href="/ess/">ESS Employee Self Service</a></li>';
        // $item .= '<li><a class="dropdown-item ws-init" href="/aset/">Kelola Aset</a></li>';
        $item .= '<li><a class="dropdown-item ws-init" href="/cuti/">Kelola Cuti & Izin</a></li>';
        $item .= '<li><a class="dropdown-item ws-init" href="/analisa-data/">Analisa Data</a></li>';
        $item .= '</ul>';
        $menu = $item . $menu;
    }
    return $menu;
}


if (isset($_GET['setup-solution-menu'])) {
    solution_menu_setup();
}
