<?php

return '<article class="bg-theme-1">
		<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--white)" class="overlay-top">
			<polygon points="0,0 0,5 50,30 100,5 100,0"/>
		</svg>
		<div class="container py-5">
			<div class="card-stack">
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/1-buat-invoice.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Buat invoice dengan desain elegan dan profesional</h3>
										<p class="fs-6 opacity-5 text-break">Cukup masukkan data dan Kledo akan membuatkan faktur dan invoice untuk pelangganmu.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/2-jenis-usaha-jasa-maupun.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Jenis usaha jasa maupun dagang, apapun bisa!</h3>
										<p class="fs-6 opacity-5 text-break">Apapun produk dan jasa yang kamu jual, pastikan buat invoice jadi lebih mudah menggunakan Kledo.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/3-laporan-penjualan-detail.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Laporan penjualan detail dan mendalam</h3>
										<p class="fs-6 opacity-5 text-break">Dapatkan laporan bisnis dan keuangan secara realtime. Ketahui produk apa yang paling laris, berapa pembayaran yang diterima tiap periode, berapa piutang dan lainnya. Segala hal tentang aspek bisnismu jadi sangat mudah dipantau.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/4-buat-penawaran-penjualan.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Buat penawaran penjualan & lacak statusnya</h3>
										<p class="fs-6 opacity-5 text-break">Kamu juga bisa membuat penawaran penjualan untuk pelangganmu dengan Kledo. Setelahnya status penawaran bisa kamu pantau dan lacak dari Kledo.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/5-buat-invoice-dari-penawaran.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Buat invoice dari penawaran hanya dengan satu klik</h3>
										<p class="fs-6 opacity-5 text-break">Tak perlu lagi input ulang untuk membuat invoice, cukup satu klik dari halaman penawaran, maka invoice mu langsung jadi.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/6-terima-pembayaran-invoice.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Terima pembayaran invoice bertahap</h3>
										<p class="fs-6 opacity-5 text-break">Pelangganmu bisa membayar invoice secara bertahap, dan Kledo sangat bisa mencatatnya dengan rapi dan benar.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/7-perhitungan-pajak-otomatis.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Perhitungan Pajak Otomatis</h3>
										<p class="fs-6 opacity-5 text-break">Semua pajak penjualan akan terrekap menjadi laporan pajak secara otomatis. Kamu bisa mengkustomisasi apapun jenis pajak yang kamu terapkan pada bisnismu.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/8-monitor-saldo-pelanggan.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Monitor Saldo Pelanggan</h3>
										<p class="fs-6 opacity-5 text-break">Monitor saldo pelangganmu jadi lebih mudah dengan Kledo. Ketahui pelanggan mana saja yang membeli lebih banyak, mana yang menunggak, dan mana yang bisa kamu prospek untuk menaikkan penjualan.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/9-impor-data-pelanggan.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Mengimpor data invoice dan penawaran dalam jumlah besar</h3>
										<p class="fs-6 opacity-5 text-break">Tak perlu lagi khawatir memasukkan ratusan data dalam waktu singkat. Cukup upload file Excel-mu, dan kledo akan mengolahnya menjadi invoice.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-stack-item mb-4">
					<div class="card p-2 p-md-3 rounded-2 border-0 shadow">
						<div class="card-body">
							<div class="row">
								<div class="col-md-7 order-md-2">
									<img class="img-fluid" loading="lazy" width="600" height="400" src="https://kledo.com/wp-content/themes/new-theme/assets2/img/backgrounds/invoice/10-stock-gudang-tercatat.webp" alt="Screenshot">
								</div>
								<div class="col-md-5 order-md-1 d-flex align-items-center">
									<div class="text-center text-md-left mb-2 mt-3 mt-md-2">
										<h3 class="fs-3 text-break mb-3">Stok dan gudang tercatat otomatis</h3>
										<p class="fs-6 opacity-5 text-break">Stok produk akan tercatat secara otomatis di gudang yang kamu tentukan. Tak perlu lagi double input untuk urusan inventori!</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<style>
				@media (min-width: 768px) {
					.card-stack {
						display: grid;
						grid-auto-rows: 1fr;
					}
					.card-stack-item {
						position: -webkit-sticky;
						position: sticky;
						top: 200px;
					}
					.card-stack-item > .card {
						height: 100%;
						-webkit-transform-origin: top center;
						-ms-transform-origin: top center;
						transform-origin: top center;
					}
					.card-stack-item > .card > .row {
						height: inherit;
					}
				}
			</style>
			<script>
				let e = document.querySelectorAll(\'.card-stack\'),
					o = [\'load\', \'resize\', \'scroll\'];
				[].forEach.call(e, function(e) {
					let t = e.querySelectorAll(\'.card-stack-item\');
					o.forEach(function(e) {
						window.addEventListener(e, function() {
							let d = [].slice.call(t).reverse();
							d.reduce(function(e, t, o) {
								let n = t.clientHeight + parseInt(window.getComputedStyle(t).getPropertyValue(\'margin-bottom\')),
								a = e + (n - (d[o - 1] ? d[o - 1].offsetTop - t.offsetTop : n)) / n,
								r = t.firstElementChild,
								l = r.firstElementChild,
								c = \'calc(-1rem * \' + a + \')\',
								i = \'calc(1 - .2 * \' + a + \')\',
								s = \'calc(1 - .03 * \' + a + \')\';
								return r.style.transform = \'translateY(\' + c + \') scale(\' + s + \')\', l.style.opacity = i, a
							}, 0)
						})
					})
				})
			</script>
		</div>
		<svg xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" viewBox="0 0 100 30" width="100%" height="50" fill="var(--theme-1-hover)" class="overlay-bottom">
			<polygon points="0,0 100,25 100,30 0,30"/>
		</svg>
	</article>';