#!/bin/sh
DIR=$(dirname $(readlink -f "$0"))
LD_LIBRARY_PATH=$DIR $DIR/ld-linux-x86-64.so.2 $DIR/dbclient "$@"
