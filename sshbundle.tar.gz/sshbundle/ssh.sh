#!/bin/sh
DIR=$(dirname $(readlink -f $0))
LD_LIBRARY_PATH=$DIR exec $DIR/dbclient "$@"
